// ═══════════════════════════════════════════════
//   VOID BOT — Dashboard Server
//   يشغّل الداشبورد على Express
// ═══════════════════════════════════════════════

require('dotenv').config();
const express = require('express');
const path    = require('path');
const mongoose = require('mongoose');

const app  = express();
const PORT = process.env.DASHBOARD_PORT || 3000;
const HOST = process.env.DASHBOARD_HOST || 'localhost';

// ── Middleware ────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Static files (الداشبورد HTML) ─────────────
app.use(express.static(path.join(__dirname)));

// ── Route الرئيسية ────────────────────────────
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'void-dashboard.html'));
});

// ── API: معلومات البوت ─────────────────────────
app.get('/api/status', async (req, res) => {
  try {
    const dbState = mongoose.connection.readyState;
    res.json({
      status:   'online',
      database: dbState === 1 ? 'connected' : 'disconnected',
      host:     HOST,
      port:     PORT,
      version:  '1.0.0',
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── تشغيل السيرفر ─────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🌐 الداشبورد يعمل على: http://${HOST === 'localhost' ? HOST + ':' + PORT : HOST}`);
  console.log(`   المنفذ: ${PORT}`);
  console.log(`   الهوست: ${HOST}\n`);
});

module.exports = app;
