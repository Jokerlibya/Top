const Member = require('../models/Member');
const Guild  = require('../models/Guild');
const Embed  = require('../utils/embed');
const config = require('../config');

// حساب كم XP يحتاج للوصول لمستوى معين
function xpForLevel(level) {
  return Math.floor(100 * Math.pow(1.5, level));
}

// إضافة XP لعضو
async function addXP(message) {
  const { author, guild, channel } = message;
  if (author.bot) return;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.levels?.enabled) return;

  // روم مستثنى من XP؟
  if (guildData.levels.noXpChannels?.includes(channel.id)) return;

  let member = await Member.findOne({ userId: author.id, guildId: guild.id });
  if (!member) {
    member = await Member.create({ userId: author.id, guildId: guild.id });
  }

  // كولداون
  const now = Date.now();
  if (member.lastXpAt && (now - member.lastXpAt.getTime()) < config.levels.xpCooldown) return;

  // أضف XP عشوائي
  const xpGain = Math.floor(
    Math.random() * (config.levels.xpPerMessage.max - config.levels.xpPerMessage.min + 1)
    + config.levels.xpPerMessage.min
  );

  member.xp       += xpGain;
  member.messages += 1;
  member.lastXpAt  = new Date();

  // تحقق من اللفل أب
  const xpNeeded = xpForLevel(member.level);
  if (member.xp >= xpNeeded) {
    member.xp    -= xpNeeded;
    member.level += 1;

    // أرسل رسالة لفل أب
    const lvlChannel = guildData.levels.channelId
      ? guild.channels.cache.get(guildData.levels.channelId)
      : channel;

    if (lvlChannel) {
      lvlChannel.send({
        embeds: [Embed.levelUp(author, member.level, guild)],
      }).catch(() => {});
    }

    // أعط الرتبة تلقائياً
    const reward = guildData.levels.rewards?.find(r => r.level === member.level);
    if (reward) {
      const gMember = guild.members.cache.get(author.id);
      const role    = guild.roles.cache.get(reward.roleId);
      if (gMember && role) {
        gMember.roles.add(role).catch(() => {});
      }
    }
  }

  await member.save();
}

// جلب لوحة المتصدرين
async function getLeaderboard(guildId, limit = 10) {
  return Member.find({ guildId })
    .sort({ level: -1, xp: -1 })
    .limit(limit)
    .lean();
}

// جلب ترتيب عضو
async function getRank(userId, guildId) {
  const members = await Member.find({ guildId }).sort({ level: -1, xp: -1 }).lean();
  const rank    = members.findIndex(m => m.userId === userId) + 1;
  const member  = members.find(m => m.userId === userId);
  return { rank, member, total: members.length };
}

module.exports = { addXP, getLeaderboard, getRank, xpForLevel };
