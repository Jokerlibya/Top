const cron   = require('node-cron');
const Member = require('../models/Member');
const Guild  = require('../models/Guild');
const Logger = require('../utils/logger');

function startScheduler(client) {
  // ── إعادة تصفير الرسائل اليومية — كل يوم الساعة 00:00 ──
  cron.schedule('0 0 * * *', async () => {
    Logger.info('[Scheduler] إعادة تصفير عداد الرسائل اليومية...');
    await Member.updateMany({}, { $set: { dailyMessages: 0 } });
    Logger.success('[Scheduler] تم تصفير الرسائل اليومية.');
  });

  // ── إعادة تصفير الرسائل الأسبوعية — كل الأحد ──
  cron.schedule('0 0 * * 0', async () => {
    Logger.info('[Scheduler] إعادة تصفير عداد الرسائل الأسبوعية...');
    await Member.updateMany({}, { $set: { weeklyMessages: 0 } });
    Logger.success('[Scheduler] تم تصفير الرسائل الأسبوعية.');
  });

  // ── رفع الكتم التلقائي المنتهي — كل دقيقة ──
  // Discord يتعامل مع Timeout تلقائياً، لكن هذا لإعادة تعيين علامة DB
  cron.schedule('* * * * *', async () => {
    const now    = new Date();
    const result = await Member.updateMany(
      { muted: true, mutedUntil: { $lt: now } },
      { $set: { muted: false, mutedUntil: null } }
    );
    if (result.modifiedCount > 0) {
      Logger.info(`[Scheduler] رُفع الكتم عن ${result.modifiedCount} عضو.`);
    }
  });

  // ── تحديث عدد الأعضاء — كل 10 دقائق ──
  cron.schedule('*/10 * * * *', async () => {
    for (const [, guild] of client.guilds.cache) {
      await Guild.updateOne(
        { guildId: guild.id },
        { $set: { 'stats.memberCount': guild.memberCount } }
      ).catch(() => {});
    }
  });

  Logger.success('[Scheduler] تم تشغيل المهام الدورية.');
}

module.exports = { startScheduler };
