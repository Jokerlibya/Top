// ═══════════════════════════════════════
//   VOID — Advanced AutoMod System
// ═══════════════════════════════════════

const Guild  = require('../models/Guild');
const Embed  = require('../utils/embed');
const Logger = require('../utils/logger');

// قوائم الكلمات الممنوعة
const BAD_WORDS = [
  // أضف كلمات هنا — مثال: 'insult1', 'insult2'
];

// تكرار نفس الرسالة
const repeatTracker = new Map();  // userId → { content, count, timer }

// رسائل مزعجة (caps lock)
function isAllCaps(text) {
  if (text.length < 8) return false;
  const letters = text.replace(/[^a-zA-Z]/g, '');
  if (!letters.length) return false;
  const upper = letters.replace(/[^A-Z]/g, '');
  return (upper.length / letters.length) > 0.8;
}

// كشف رسائل مكررة
function checkRepeat(message) {
  const { author, content } = message;
  const key    = author.id;
  const now    = Date.now();
  const entry  = repeatTracker.get(key);

  if (entry && entry.content === content && (now - entry.time) < 10000) {
    entry.count++;
    entry.time = now;
    if (entry.count >= 3) {
      repeatTracker.delete(key);
      return true;
    }
  } else {
    repeatTracker.set(key, { content, count: 1, time: now });
    if (entry?.timer) clearTimeout(entry.timer);
    const timer = setTimeout(() => repeatTracker.delete(key), 15000);
    repeatTracker.get(key).timer = timer;
  }
  return false;
}

// كشف روابط الديسكورد (Invites)
const INVITE_REGEX = /(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/[a-zA-Z0-9]+/gi;

function hasInvite(content) {
  return INVITE_REGEX.test(content);
}

// كشف الكلمات الممنوعة
function hasBadWords(content) {
  const lower = content.toLowerCase();
  return BAD_WORDS.some(word => lower.includes(word));
}

// التشغيل الرئيسي
async function runAutoMod(message) {
  const { author, guild, member, content, channel } = message;

  if (author.bot) return false;
  if (!content || content.trim().length === 0) return false;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.moderation?.autoModEnabled) return false;

  // تجاهل المشرفين والأدمن
  const { PermissionFlagsBits } = require('discord.js');
  if (member?.permissions.has(PermissionFlagsBits.ManageMessages)) return false;

  let triggered = false;
  let reason    = '';

  // ── فحص الكلمات الممنوعة ──
  if (hasBadWords(content)) {
    triggered = true;
    reason    = 'كلمات ممنوعة';
  }

  // ── فحص الدعوات ──
  else if (hasInvite(content) && guildData.protection?.antiLinks?.enabled) {
    triggered = true;
    reason    = 'رابط دعوة غير مسموح';
  }

  // ── فحص التكرار ──
  else if (checkRepeat(message)) {
    triggered = true;
    reason    = 'رسائل مكررة';
  }

  // ── فحص كابس لوك مزعج ──
  else if (isAllCaps(content)) {
    triggered = true;
    reason    = 'كابس لوك مفرط';
  }

  if (triggered) {
    await message.delete().catch(() => {});

    const warn = await channel.send({
      embeds: [Embed.warning(`⚠️ ${author}، تم حذف رسالتك: **${reason}**`)],
    });
    setTimeout(() => warn.delete().catch(() => {}), 5000);

    Logger.warn(`[AUTOMOD] ${author.tag} في ${guild.name}: ${reason}`);
    return true;
  }

  return false;
}

module.exports = { runAutoMod, hasBadWords, hasInvite };
