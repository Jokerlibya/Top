const { PermissionFlagsBits } = require('discord.js');
const Guild  = require('../models/Guild');
const Member = require('../models/Member');
const Embed  = require('../utils/embed');
const Logger = require('../utils/logger');

// سجل الرسائل المتكررة لكل مستخدم
const spamTracker = new Map(); // userId → [timestamps]
const raidTracker = new Map(); // guildId → { count, timer }

// ── Anti Spam ──────────────────────────────
async function checkSpam(message) {
  const { author, guild } = message;
  if (author.bot) return false;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.protection?.antiSpam?.enabled) return false;

  const key  = `${guild.id}:${author.id}`;
  const now  = Date.now();
  const cfg  = guildData.protection.antiSpam;
  const max  = cfg.max || 7;
  const win  = cfg.window || 5000;

  const times = (spamTracker.get(key) || []).filter(t => now - t < win);
  times.push(now);
  spamTracker.set(key, times);

  if (times.length >= max) {
    spamTracker.delete(key);
    await punish(message, cfg.action || 'mute', 'سبام - إرسال رسائل متكررة', 5 * 60 * 1000);
    return true;
  }
  return false;
}

// ── Anti Links ─────────────────────────────
const LINK_REGEX = /(https?:\/\/|discord\.gg\/|www\.)[^\s]+/gi;

async function checkLinks(message) {
  const { author, guild, member } = message;
  if (author.bot) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return false;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.protection?.antiLinks?.enabled) return false;

  const whitelist = guildData.protection.antiLinks.whitelist || [];
  const hasLink   = LINK_REGEX.test(message.content);

  if (hasLink) {
    const isWhitelisted = whitelist.some(w => message.content.includes(w));
    if (!isWhitelisted) {
      await message.delete().catch(() => {});
      const warn = await message.channel.send({
        embeds: [Embed.warning(`${author}, الروابط غير مسموحة في هذا السيرفر!`)],
      });
      setTimeout(() => warn.delete().catch(() => {}), 5000);
      return true;
    }
  }
  return false;
}

// ── Anti Mention ───────────────────────────
async function checkMentions(message) {
  const { author, guild, mentions } = message;
  if (author.bot) return false;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.protection?.antiMention?.enabled) return false;

  const max = guildData.protection.antiMention.max || 5;
  const total = mentions.users.size + mentions.roles.size;

  if (total >= max) {
    await punish(message, 'mute', `منشنات مفرطة (${total} منشن)`, 5 * 60 * 1000);
    return true;
  }
  return false;
}

// ── Anti Raid ──────────────────────────────
async function checkRaid(member) {
  const { guild } = member;
  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.protection?.antiRaid?.enabled) return;

  const now       = Date.now();
  const threshold = 10;
  const window    = 10000;

  let tracker = raidTracker.get(guild.id) || { count: 0, start: now };

  if (now - tracker.start > window) {
    tracker = { count: 1, start: now };
  } else {
    tracker.count++;
  }

  raidTracker.set(guild.id, tracker);

  if (tracker.count >= threshold) {
    raidTracker.delete(guild.id);
    Logger.warn(`[RAID DETECTED] السيرفر: ${guild.name}`);

    // قفل جميع الرومات
    const channels = guild.channels.cache.filter(c => c.isTextBased());
    for (const [, ch] of channels) {
      ch.permissionOverwrites.edit(guild.roles.everyone, {
        SendMessages: false,
      }).catch(() => {});
    }

    // إشعار في لوق الإدارة
    const logCh = guild.channels.cache.find(
      c => c.name === 'void-logs' || c.id === guildData.moderation?.logChannelId
    );

    if (logCh) {
      logCh.send({
        embeds: [Embed.warning(
          `🚨 **تم اكتشاف غزوة (Raid)!**\nتم قفل جميع الرومات تلقائياً.\n${tracker.count} عضو انضم خلال ${window / 1000} ثوان.`,
          '🛡️ حماية من الغزوة'
        )],
      }).catch(() => {});
    }
  }
}

// ── Anti New Account ───────────────────────
async function checkNewAccount(member) {
  const { guild, user } = member;
  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.protection?.antiNewAcc?.enabled) return;

  const days      = guildData.protection.antiNewAcc.days || 7;
  const ageMs     = Date.now() - user.createdTimestamp;
  const threshold = days * 24 * 60 * 60 * 1000;

  if (ageMs < threshold) {
    await member.kick(`حساب جديد (عمر الحساب أقل من ${days} أيام)`).catch(() => {});
    Logger.warn(`[NEW ACCOUNT KICKED] ${user.tag} in ${guild.name}`);
  }
}

// ── Punish Helper ──────────────────────────
async function punish(message, action, reason, duration = null) {
  const { author, guild, channel } = message;

  try {
    // احذف الرسالة
    await message.delete().catch(() => {});

    const guildMember = guild.members.cache.get(author.id);
    if (!guildMember) return;

    if (action === 'mute' || action === 'timeout') {
      await guildMember.timeout(duration || 5 * 60 * 1000, reason);
    } else if (action === 'kick') {
      await guildMember.kick(reason);
    } else if (action === 'ban') {
      await guild.members.ban(author.id, { reason });
    }

    // أضف تحذير
    await Member.findOneAndUpdate(
      { userId: author.id, guildId: guild.id },
      {
        $push: {
          warnings: {
            reason,
            moderator: guild.client.user.id,
            id: `AUTO-${Date.now()}`,
          }
        }
      },
      { upsert: true }
    );

    const warn = await channel.send({
      embeds: [Embed.warning(`${author}, تم ${action === 'mute' ? 'كتمك' : 'معاقبتك'} بسبب: **${reason}**`)],
    });
    setTimeout(() => warn.delete().catch(() => {}), 8000);

  } catch (err) {
    Logger.error(`[PROTECTION] خطأ في معاقبة ${author.tag}:`, err.message);
  }
}

module.exports = { checkSpam, checkLinks, checkMentions, checkRaid, checkNewAccount };
