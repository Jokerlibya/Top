const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// إنشاء صورة ترحيب بالـ Canvas
async function generateWelcomeImage(member, settings = {}) {
  const width  = 800;
  const height = 250;
  const canvas = createCanvas(width, height);
  const ctx    = canvas.getContext('2d');

  // ── خلفية ──
  const bgColor = settings.backgroundColor || '#0a0a0f';
  ctx.fillStyle = bgColor;
  ctx.roundRect(0, 0, width, height, 20);
  ctx.fill();

  // ── تدرج بنفسجي على الجانب ──
  const grad = ctx.createLinearGradient(0, 0, width * 0.4, 0);
  grad.addColorStop(0, 'rgba(124, 58, 237, 0.3)');
  grad.addColorStop(1, 'rgba(124, 58, 237, 0)');
  ctx.fillStyle = grad;
  ctx.roundRect(0, 0, width, height, 20);
  ctx.fill();

  // ── خط جانبي ──
  ctx.fillStyle = '#7c3aed';
  ctx.fillRect(0, 0, 4, height);

  // ── صورة العضو (دائرة) ──
  const avatarSize = 120;
  const avatarX    = 60;
  const avatarY    = (height - avatarSize) / 2;

  ctx.save();
  ctx.beginPath();
  ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2);
  ctx.clip();

  try {
    const avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
    const avatar    = await loadImage(avatarURL);
    ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);
  } catch {
    ctx.fillStyle = '#7c3aed';
    ctx.fill();
    ctx.fillStyle = 'white';
    ctx.font      = 'bold 36px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(
      member.user.username.charAt(0).toUpperCase(),
      avatarX + avatarSize / 2,
      avatarY + avatarSize / 2 + 13
    );
  }

  ctx.restore();

  // ── حلقة حول الأفاتار ──
  ctx.strokeStyle = '#7c3aed';
  ctx.lineWidth   = 3;
  ctx.beginPath();
  ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2 + 4, 0, Math.PI * 2);
  ctx.stroke();

  // ── النصوص ──
  const textX = avatarX + avatarSize + 30;
  const textColor = settings.textColor || '#ffffff';

  // أهلاً وسهلاً
  ctx.fillStyle = '#a78bfa';
  ctx.font      = '500 20px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('أهلاً وسهلاً!', textX, height * 0.35);

  // اسم العضو
  ctx.fillStyle = textColor;
  ctx.font      = 'bold 32px sans-serif';
  const username = member.user.username;
  const maxWidth = width - textX - 40;
  const displayName = username.length > 20 ? username.slice(0, 18) + '...' : username;
  ctx.fillText(displayName, textX, height * 0.35 + 40);

  // اسم السيرفر
  ctx.fillStyle = '#94a3b8';
  ctx.font      = '18px sans-serif';
  ctx.fillText(`في ${member.guild.name}`, textX, height * 0.35 + 75);

  // عدد الأعضاء
  ctx.fillStyle = '#64748b';
  ctx.font      = '14px sans-serif';
  ctx.fillText(`العضو رقم ${member.guild.memberCount}`, textX, height * 0.35 + 105);

  return canvas.toBuffer('image/png');
}

module.exports = { generateWelcomeImage };
