const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const Guild  = require('../models/Guild');
const config = require('../config');

async function log(guild, type, data) {
  const guildData = await Guild.findOne({ guildId: guild.id });
  const logChannelId = guildData?.moderation?.logChannelId;
  if (!logChannelId) return;

  const channel = guild.channels.cache.get(logChannelId);
  if (!channel) return;

  const embed = buildLogEmbed(type, data);
  if (!embed) return;

  channel.send({ embeds: [embed] }).catch(() => {});
}

function buildLogEmbed(type, data) {
  const colors = {
    ban:           config.colors.danger,
    unban:         config.colors.success,
    kick:          config.colors.warning,
    mute:          config.colors.warning,
    unmute:        config.colors.success,
    warn:          config.colors.warning,
    messageDelete: 0x64748b,
    messageEdit:   0x3b82f6,
    memberJoin:    config.colors.success,
    memberLeave:   config.colors.danger,
    roleAdd:       config.colors.info,
    roleRemove:    0x64748b,
    channelCreate: config.colors.success,
    channelDelete: config.colors.danger,
  };

  const titles = {
    ban:           '🔨 حظر',
    unban:         '🔓 رفع الحظر',
    kick:          '👢 طرد',
    mute:          '🔇 كتم',
    unmute:        '🔊 رفع الكتم',
    warn:          '⚠️ تحذير',
    messageDelete: '🗑️ حذف رسالة',
    messageEdit:   '✏️ تعديل رسالة',
    memberJoin:    '📥 عضو انضم',
    memberLeave:   '📤 عضو غادر',
    roleAdd:       '🏷️ إضافة رتبة',
    roleRemove:    '🏷️ إزالة رتبة',
    channelCreate: '📝 إنشاء روم',
    channelDelete: '🗑️ حذف روم',
  };

  const e = new EmbedBuilder()
    .setColor(colors[type] || config.colors.primary)
    .setTitle(titles[type] || type)
    .setTimestamp();

  // بناء الفيلدز حسب النوع
  if (data.user) {
    e.setThumbnail(data.user.displayAvatarURL?.({ dynamic: true }) || null);
    e.addFields({ name: '👤 المستخدم', value: `${data.user.tag || data.user}\n\`${data.user.id || data.user}\``, inline: true });
  }
  if (data.moderator) e.addFields({ name: '🛡️ المشرف', value: `${data.moderator}`, inline: true });
  if (data.reason)    e.addFields({ name: '📝 السبب', value: data.reason, inline: false });
  if (data.channel)   e.addFields({ name: '📍 الروم', value: `${data.channel}`, inline: true });
  if (data.duration)  e.addFields({ name: '⏱️ المدة', value: data.duration, inline: true });
  if (data.content)   e.addFields({ name: '📄 المحتوى', value: `\`\`\`${data.content.slice(0, 1000)}\`\`\``, inline: false });
  if (data.before)    e.addFields({ name: '📄 قبل', value: `\`\`\`${data.before.slice(0, 500)}\`\`\``, inline: true });
  if (data.after)     e.addFields({ name: '📄 بعد', value: `\`\`\`${data.after.slice(0, 500)}\`\`\``, inline: true });
  if (data.role)      e.addFields({ name: '🏷️ الرتبة', value: `${data.role}`, inline: true });
  if (data.extra)     e.addFields({ name: 'معلومات إضافية', value: data.extra, inline: false });

  if (data.caseId) e.setFooter({ text: `Case #${data.caseId}` });

  return e;
}

module.exports = { log };
