const {
  ChannelType, PermissionFlagsBits,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, EmbedBuilder
} = require('discord.js');
const Ticket = require('../models/Ticket');
const Guild  = require('../models/Guild');
const Embed  = require('../utils/embed');
const config = require('../config');

// إنشاء بانيل التذاكر
async function createPanel(channel, guildData) {
  const select = new StringSelectMenuBuilder()
    .setCustomId('ticket_create')
    .setPlaceholder('اختر نوع التذكرة...')
    .addOptions(
      config.tickets.categories.map(cat => ({
        label:       cat.label,
        value:       cat.id,
        description: cat.description,
        emoji:       cat.label.match(/^\p{Emoji}/u)?.[0] || '📩',
      }))
    );

  const row = new ActionRowBuilder().addComponents(select);

  const embed = new EmbedBuilder()
    .setColor(config.colors.primary)
    .setTitle('🎫 نظام التذاكر')
    .setDescription('اختر نوع التذكرة من القائمة أدناه للحصول على الدعم المناسب.')
    .addFields(
      config.tickets.categories.map(cat => ({
        name:   cat.label,
        value:  cat.description,
        inline: true,
      }))
    )
    .setFooter({ text: 'Void Ticket System' })
    .setTimestamp();

  return channel.send({ embeds: [embed], components: [row] });
}

// فتح تذكرة جديدة
async function openTicket(interaction, type) {
  const { guild, user } = interaction;

  const guildData = await Guild.findOne({ guildId: guild.id });
  if (!guildData?.tickets?.enabled) {
    return interaction.reply({ embeds: [Embed.error('نظام التذاكر غير مفعل.')], ephemeral: true });
  }

  // تحقق من عدد التذاكر المفتوحة
  const openTickets = await Ticket.countDocuments({ guildId: guild.id, userId: user.id, status: 'open' });
  if (openTickets >= config.tickets.maxOpenPerUser) {
    return interaction.reply({
      embeds: [Embed.warning('لديك تذكرة مفتوحة مسبقاً! أغلقها أولاً.')],
      ephemeral: true,
    });
  }

  const category = config.tickets.categories.find(c => c.id === type);
  const ticketId = `${type}-${Date.now().toString(36).toUpperCase()}`;

  // أنشئ الروم
  const permissions = [
    {
      id:    guild.roles.everyone,
      deny:  [PermissionFlagsBits.ViewChannel],
    },
    {
      id:      user.id,
      allow:   [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    },
  ];

  if (guildData.tickets.supportRoleId) {
    permissions.push({
      id:    guildData.tickets.supportRoleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
    });
  }

  const channel = await guild.channels.create({
    name:     `ticket-${user.username.toLowerCase()}-${ticketId.toLowerCase()}`,
    type:     ChannelType.GuildText,
    parent:   guildData.tickets.categoryId || null,
    permissionOverwrites: permissions,
    reason:   `تذكرة جديدة من ${user.tag}`,
  });

  // سجّل في قاعدة البيانات
  const ticket = await Ticket.create({
    ticketId,
    guildId:   guild.id,
    userId:    user.id,
    channelId: channel.id,
    type,
    subject:   category?.label || type,
  });

  await Guild.updateOne({ guildId: guild.id }, { $inc: { 'tickets.openCount': 1, 'tickets.totalCount': 1 } });

  // أرسل رسالة داخل الروم
  const closeBtn = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('استلام التذكرة').setStyle(ButtonStyle.Success).setEmoji('✋'),
  );

  const ticketEmbed = new EmbedBuilder()
    .setColor(config.colors.primary)
    .setTitle(`${category?.label || '🎫 تذكرة'} — ${ticketId}`)
    .setDescription(`مرحباً ${user}!\nتذكرتك مفتوحة. سيتواصل معك فريق الدعم قريباً.\n\n📝 صف مشكلتك بالتفصيل وسنساعدك.`)
    .addFields({ name: 'النوع', value: category?.label || type, inline: true })
    .setTimestamp()
    .setFooter({ text: `Void Tickets • ${ticketId}` });

  await channel.send({ content: `${user}`, embeds: [ticketEmbed], components: [closeBtn] });

  // رد على المستخدم
  await interaction.reply({
    embeds: [Embed.success(`تم إنشاء تذكرتك! ${channel}`)],
    ephemeral: true,
  });

  return ticket;
}

// إغلاق التذكرة
async function closeTicket(interaction) {
  const { guild, channel, user } = interaction;

  const ticket = await Ticket.findOne({ channelId: channel.id, status: 'open' });
  if (!ticket) {
    return interaction.reply({ embeds: [Embed.error('لا توجد تذكرة مفتوحة في هذا الروم.')], ephemeral: true });
  }

  await interaction.reply({
    embeds: [Embed.warning('جاري إغلاق التذكرة وحفظ السجل...')],
  });

  // احفظ الترانسكريبت
  const messages = await channel.messages.fetch({ limit: 100 });
  const transcript = messages.reverse().map(m =>
    `[${m.createdAt.toLocaleString('ar-SA')}] ${m.author.tag}: ${m.content || '[Embed/Attachment]'}`
  ).join('\n');

  // حدّث في DB
  await Ticket.updateOne({ channelId: channel.id }, {
    status:    'closed',
    closedBy:  user.id,
    closedAt:  new Date(),
    messages:  messages.map(m => ({
      author:    m.author.tag,
      content:   m.content || '[embed]',
      timestamp: m.createdAt,
    })),
  });

  await Guild.updateOne({ guildId: guild.id }, { $inc: { 'tickets.openCount': -1 } });

  // أرسل الترانسكريبت
  const guildData = await Guild.findOne({ guildId: guild.id });
  const transcriptCh = guild.channels.cache.get(guildData?.tickets?.transcriptChannelId);

  if (transcriptCh) {
    const buf = Buffer.from(transcript, 'utf8');
    transcriptCh.send({
      embeds: [new EmbedBuilder()
        .setColor(config.colors.info)
        .setTitle(`📄 ترانسكريبت — ${ticket.ticketId}`)
        .addFields(
          { name: 'صاحب التذكرة', value: `<@${ticket.userId}>`, inline: true },
          { name: 'أغلقها', value: `${user}`, inline: true },
          { name: 'النوع', value: ticket.type, inline: true },
        )
        .setTimestamp()],
      files: [{ attachment: buf, name: `transcript-${ticket.ticketId}.txt` }],
    }).catch(() => {});
  }

  // احذف الروم بعد 5 ثوان
  setTimeout(() => channel.delete('تذكرة مغلقة').catch(() => {}), 5000);
}

module.exports = { createPanel, openTicket, closeTicket };
