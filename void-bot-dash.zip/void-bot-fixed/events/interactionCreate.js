const Logger  = require('../utils/logger');
const Embed   = require('../utils/embed');
const Tickets = require('../systems/tickets');

module.exports = {
  name: 'interactionCreate',

  async execute(interaction, client) {

    // ── Slash Commands ──
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        Logger.cmd(`/${interaction.commandName} | ${interaction.user.tag} | ${interaction.guild?.name}`);
        await command.execute(interaction, client);
      } catch (err) {
        Logger.error(`خطأ في الأمر /${interaction.commandName}:`, err);
        const reply = { embeds: [Embed.error('حدث خطأ أثناء تنفيذ الأمر.')], ephemeral: true };
        interaction.replied || interaction.deferred
          ? interaction.followUp(reply)
          : interaction.reply(reply);
      }
    }

    // ── Buttons ──
    else if (interaction.isButton()) {
      const { customId } = interaction;

      if (customId === 'ticket_close') {
        return Tickets.closeTicket(interaction);
      }

      if (customId === 'ticket_claim') {
        return interaction.reply({
          embeds: [Embed.success(`${interaction.user} استلم هذه التذكرة.`)],
        });
      }

      // مرّر للأمر المعني
      const [cmdName] = customId.split('_');
      const command = client.commands.get(cmdName);
      if (command?.handleButton) {
        command.handleButton(interaction, client).catch(Logger.error);
      }
    }

    // ── Select Menus ──
    else if (interaction.isStringSelectMenu()) {
      const { customId } = interaction;

      if (customId === 'ticket_create') {
        const type = interaction.values[0];
        return Tickets.openTicket(interaction, type);
      }

      const [cmdName] = customId.split('_');
      const command = client.commands.get(cmdName);
      if (command?.handleSelect) {
        command.handleSelect(interaction, client).catch(Logger.error);
      }
    }

    // ── Autocomplete ──
    else if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (command?.autocomplete) {
        command.autocomplete(interaction, client).catch(Logger.error);
      }
    }
  },
};
