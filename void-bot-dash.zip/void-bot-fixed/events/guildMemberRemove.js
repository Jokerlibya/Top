const { EmbedBuilder } = require('discord.js');
const Guild  = require('../models/Guild');
const modlog = require('../systems/modlog');

module.exports = {
  name: 'guildMemberRemove',

  async execute(member, client) {
    const { guild, user } = member;

    const guildData = await Guild.findOne({ guildId: guild.id });
    if (!guildData) return;

    // ── رسالة الوداع ──
    if (guildData.goodbye?.enabled && guildData.goodbye?.channelId) {
      const channel = guild.channels.cache.get(guildData.goodbye.channelId);
      if (channel) {
        const msg = (guildData.goodbye.message || 'وداعاً {username}! 👋')
          .replace('{user}',     `${user}`)
          .replace('{username}', user.username)
          .replace('{server}',   guild.name)
          .replace('{count}',    guild.memberCount);

        const embed = new EmbedBuilder()
          .setColor(0xEF4444)
          .setTitle('📤 غادر السيرفر')
          .setDescription(msg)
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .addFields(
            { name: '📅 كان معنا', value: member.joinedAt
              ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`
              : 'غير معروف', inline: true },
            { name: '👥 الأعضاء الآن', value: `${guild.memberCount}`, inline: true },
          )
          .setTimestamp();

        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // ── سجل ──
    await modlog.log(guild, 'memberLeave', { user });

    Guild.updateOne({ guildId: guild.id }, { 'stats.memberCount': guild.memberCount }).catch(() => {});
  },
};
