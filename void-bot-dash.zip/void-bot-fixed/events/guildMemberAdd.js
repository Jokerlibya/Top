const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Guild      = require('../models/Guild');
const Protection = require('../systems/protection');
const modlog     = require('../systems/modlog');

module.exports = {
  name: 'guildMemberAdd',

  async execute(member, client) {
    const { guild, user } = member;

    // ── حماية من الحسابات الجديدة ──
    await Protection.checkNewAccount(member);

    // ── Anti Raid ──
    await Protection.checkRaid(member);

    const guildData = await Guild.findOne({ guildId: guild.id });
    if (!guildData) return;

    // ── رتبة تلقائية ──
    if (guildData.welcome?.autoRoleId) {
      const role = guild.roles.cache.get(guildData.welcome.autoRoleId);
      if (role) member.roles.add(role).catch(() => {});
    }

    // ── رسالة الترحيب ──
    if (guildData.welcome?.enabled && guildData.welcome?.channelId) {
      const channel = guild.channels.cache.get(guildData.welcome.channelId);
      if (!channel) return;

      const msg = (guildData.welcome.message || 'مرحباً {user} في {server}!')
        .replace('{user}', `${member}`)
        .replace('{username}', user.username)
        .replace('{server}', guild.name)
        .replace('{count}', guild.memberCount);

      const embed = new EmbedBuilder()
        .setColor(0x7C3AED)
        .setTitle(`🌌 أهلاً في ${guild.name}!`)
        .setDescription(msg)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '📅 تاريخ الإنضمام', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
          { name: '👥 العضو رقم', value: `#${guild.memberCount}`, inline: true },
        )
        .setImage('https://i.imgur.com/void-welcome-banner.png') // استبدل برابط صورتك
        .setTimestamp();

      channel.send({ content: `${member}`, embeds: [embed] }).catch(() => {});
    }

    // ── سجل ──
    await modlog.log(guild, 'memberJoin', {
      user,
      extra: `<t:${Math.floor(user.createdTimestamp / 1000)}:R> تاريخ إنشاء الحساب`,
    });

    // ── تحديث إحصائيات ──
    Guild.updateOne({ guildId: guild.id }, { 'stats.memberCount': guild.memberCount }).catch(() => {});
  },
};
