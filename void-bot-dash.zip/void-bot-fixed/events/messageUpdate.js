const modlog = require('../systems/modlog');

module.exports = {
  name: 'messageUpdate',

  async execute(oldMsg, newMsg, client) {
    if (oldMsg.author?.bot || !oldMsg.guild) return;
    if (oldMsg.content === newMsg.content) return;

    await modlog.log(oldMsg.guild, 'messageEdit', {
      user:    oldMsg.author,
      channel: oldMsg.channel,
      before:  oldMsg.content || '[لا يوجد محتوى]',
      after:   newMsg.content  || '[لا يوجد محتوى]',
    });
  },
};
