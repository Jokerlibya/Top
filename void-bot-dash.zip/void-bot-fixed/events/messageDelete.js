const modlog = require('../systems/modlog');

module.exports = {
  name: 'messageDelete',

  async execute(message, client) {
    if (message.author?.bot || !message.guild) return;
    if (!message.content) return;

    await modlog.log(message.guild, 'messageDelete', {
      user:    message.author,
      channel: message.channel,
      content: message.content,
    });
  },
};
