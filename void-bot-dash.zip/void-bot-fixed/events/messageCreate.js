const { PermissionFlagsBits } = require('discord.js');
const Leveling   = require('../systems/leveling');
const Protection = require('../systems/protection');
const Guild      = require('../models/Guild');
const Logger     = require('../utils/logger');

module.exports = {
  name: 'messageCreate',

  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    // ── أوامر البريفكس (اختياري - الأساس Slash) ──
    const guildData = await Guild.findOne({ guildId: message.guild.id }).lean();
    const prefix    = guildData?.prefix || process.env.PREFIX || '!';

    if (message.content.startsWith(prefix)) {
      const args    = message.content.slice(prefix.length).trim().split(/\s+/);
      const cmdName = args.shift().toLowerCase();
      const command = client.commands.get(cmdName)
                   || client.commands.find(c => c.aliases?.includes(cmdName));

      if (command?.executeLegacy) {
        try {
          await command.executeLegacy(message, args, client);
        } catch (err) {
          Logger.error(`خطأ في الأمر ${cmdName}:`, err.message);
        }
        return;
      }
    }

    // ── الحماية التلقائية ──
    const member = message.member;
    if (!member?.permissions.has(PermissionFlagsBits.Administrator)) {
      const spammed   = await Protection.checkSpam(message);
      if (spammed) return;

      const hasLink  = await Protection.checkLinks(message);
      if (hasLink) return;

      await Protection.checkMentions(message);
    }

    // ── نظام الليفل ──
    await Leveling.addXP(message).catch(() => {});

    // ── إحصائيات ──
    Guild.updateOne(
      { guildId: message.guild.id },
      { $inc: { 'stats.totalMessages': 1 } }
    ).catch(() => {});
  },
};
