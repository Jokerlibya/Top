const { ActivityType } = require('discord.js');
const Logger = require('../utils/logger');
const mongoose = require('mongoose');

module.exports = {
  name: 'ready',
  once: true,

  async execute(client) {
    Logger.void();
    Logger.success(`سجّل الدخول: ${client.user.tag}`);
    Logger.info(`السيرفرات: ${client.guilds.cache.size}`);
    Logger.info(`الأعضاء: ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0)}`);

    // عنوان الداشبورد من .env — غيّر DASHBOARD_HOST لأي هوست أو دومين
    const dashboardHost = process.env.DASHBOARD_HOST || 'localhost';
    const dashboardPort = process.env.DASHBOARD_PORT || 3000;
    const dashboardUrl  = dashboardHost === 'localhost'
      ? `${dashboardHost}:${dashboardPort}`
      : dashboardHost;

    Logger.info(`الداشبورد: http://${dashboardUrl}`);

    // تغيير الـ Status دوريًا
    const statuses = [
      { name: '/help | Void Bot', type: ActivityType.Watching },
      { name: `${client.guilds.cache.size} سيرفر`, type: ActivityType.Watching },
      { name: 'بوت شامل متكامل', type: ActivityType.Playing },
      { name: dashboardUrl, type: ActivityType.Watching },
    ];

    let i = 0;
    const setStatus = () => {
      const s = statuses[i % statuses.length];
      client.user.setPresence({
        activities: [{ name: s.name, type: s.type }],
        status: 'online',
      });
      i++;
    };

    setStatus();
    setInterval(setStatus, 30_000);

    Logger.db(`اتصال MongoDB: ${mongoose.connection.readyState === 1 ? '✅ متصل' : '❌ غير متصل'}`);
  },
};
