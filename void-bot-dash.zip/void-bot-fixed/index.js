// ═══════════════════════════════════════════════
//   VOID BOT — Main Entry Point
//   Ultimate All-in-One Discord Bot
// ═══════════════════════════════════════════════

require('dotenv').config();
const {
  Client, GatewayIntentBits, Partials, Collection
} = require('discord.js');
const mongoose = require('mongoose');
const Logger   = require('./utils/logger');
const { loadCommands, registerCommands } = require('./handlers/commandHandler');
const { loadEvents }                     = require('./handlers/eventHandler');

// ── إنشاء الكلاينت ──────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.GuildMember,
    Partials.Reaction,
  ],
  allowedMentions: {
    parse:       ['users', 'roles'],
    repliedUser: false,
  },
});

// ── Collections ──────────────────────────────────
client.commands  = new Collection();
client.cooldowns = new Collection();

// ── Startup ───────────────────────────────────────
async function start() {
  try {
    // اتصال MongoDB
    Logger.db('جاري الاتصال بـ MongoDB...');
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/voidbot', {
      serverSelectionTimeoutMS: 5000,
    });
    Logger.success('تم الاتصال بـ MongoDB بنجاح!');

    // تحميل الأوامر والأحداث
    const commands = await loadCommands(client);
    loadEvents(client);

    // تسجيل slash commands
    await registerCommands(client, commands);

    // تسجيل الدخول
    await client.login(process.env.TOKEN);

  } catch (err) {
    Logger.error('فشل تشغيل البوت:', err.message);
    if (err.message.includes('MongoDB')) {
      Logger.warn('تأكد من تشغيل MongoDB وصحة MONGO_URI في ملف .env');
    }
    process.exit(1);
  }
}

// ── Error Handling ────────────────────────────────
process.on('unhandledRejection', (reason) => {
  Logger.error('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  Logger.error('Uncaught Exception:', err.message);
});

client.on('error', (err) => {
  Logger.error('Discord Client Error:', err.message);
});

client.on('warn', (info) => {
  Logger.warn('Discord Warning:', info);
});

// ── Graceful Shutdown ─────────────────────────────
process.on('SIGINT', async () => {
  Logger.warn('إيقاف البوت...');
  await mongoose.disconnect();
  client.destroy();
  process.exit(0);
});

// ── Start ─────────────────────────────────────────
start();
