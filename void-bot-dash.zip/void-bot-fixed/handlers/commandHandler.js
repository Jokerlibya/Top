const fs   = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const Logger = require('../utils/logger');

async function loadCommands(client) {
  const commands = [];
  const commandsPath = path.join(__dirname, '..', 'commands');

  const categories = fs.readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));

    for (const file of files) {
      try {
        const command = require(path.join(categoryPath, file));

        if (!command.data || !command.execute) {
          Logger.warn(`الأمر ${file} ينقصه data أو execute`);
          continue;
        }

        client.commands.set(command.data.name, command);
        commands.push(command.data.toJSON());
        Logger.debug(`تحميل أمر: /${command.data.name}`);
      } catch (err) {
        Logger.error(`خطأ في تحميل ${file}:`, err.message);
      }
    }
  }

  Logger.success(`تم تحميل ${client.commands.size} أمر`);
  return commands;
}

async function registerCommands(client, commands) {
  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

  try {
    Logger.info('جاري تسجيل slash commands...');

    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );

    Logger.success(`تم تسجيل ${commands.length} slash command بنجاح`);
  } catch (err) {
    Logger.error('خطأ في تسجيل الأوامر:', err.message);
  }
}

module.exports = { loadCommands, registerCommands };
