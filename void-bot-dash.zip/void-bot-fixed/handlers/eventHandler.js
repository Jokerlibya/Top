const fs   = require('fs');
const path = require('path');
const Logger = require('../utils/logger');

function loadEvents(client) {
  const eventsPath = path.join(__dirname, '..', 'events');
  const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));

  for (const file of files) {
    try {
      const event = require(path.join(eventsPath, file));

      if (!event.name || !event.execute) {
        Logger.warn(`الحدث ${file} ينقصه name أو execute`);
        continue;
      }

      const handler = (...args) => event.execute(...args, client);

      if (event.once) {
        client.once(event.name, handler);
      } else {
        client.on(event.name, handler);
      }

      Logger.debug(`تحميل حدث: ${event.name}`);
    } catch (err) {
      Logger.error(`خطأ في تحميل ${file}:`, err.message);
    }
  }

  Logger.success(`تم تحميل ${files.length} حدث`);
}

module.exports = { loadEvents };
