// ═══════════════════════════════════════
//   VOID BOT — Central Configuration
// ═══════════════════════════════════════

module.exports = {
  // ── Bot Info ──
  name: 'Void',
  version: '1.0.0',
  prefix: process.env.PREFIX || '!',
  owners: [process.env.OWNER_ID].filter(Boolean),
  supportServer: process.env.SUPPORT_SERVER || 'https://discord.gg/void',

  // ── Colors ──
  colors: {
    primary:   0x7C3AED,   // بنفسجي
    secondary: 0x3B82F6,   // أزرق
    success:   0x10B981,   // أخضر
    warning:   0xF59E0B,   // أصفر
    danger:    0xEF4444,   // أحمر
    info:      0x06B6D4,   // سماوي
    default:   0x0F0F1A,   // خلفية
  },

  // ── Emojis ──
  emojis: {
    success:   '✅',
    error:     '❌',
    warning:   '⚠️',
    loading:   '⏳',
    ban:       '🔨',
    kick:      '👢',
    mute:      '🔇',
    warn:      '⚠️',
    ticket:    '🎫',
    star:      '⭐',
    crown:     '👑',
    shield:    '🛡️',
    robot:     '🤖',
    music:     '🎵',
    chart:     '📊',
    gift:      '🎁',
    lock:      '🔒',
    unlock:    '🔓',
    up:        '⬆️',
    void:      '🌌',
  },

  // ── Moderation Defaults ──
  mod: {
    muteRoleName: 'Muted',
    logChannelName: 'void-logs',
    maxWarnings: 3,
    autobanOnMaxWarns: true,
    defaultMuteDuration: 10 * 60 * 1000, // 10 دقائق
  },

  // ── Leveling System ──
  levels: {
    xpPerMessage: { min: 15, max: 40 },
    xpCooldown: 60 * 1000, // دقيقة واحدة
    xpFormula: (level) => Math.floor(100 * Math.pow(1.5, level)),
  },

  // ── Tickets ──
  tickets: {
    maxOpenPerUser: 1,
    transcriptEnabled: true,
    categories: [
      { id: 'support',     label: '🛠️ دعم فني',          description: 'مشاكل تقنية أو استفسارات' },
      { id: 'purchase',    label: '🛒 شراء',              description: 'طلبات شراء ومنتجات' },
      { id: 'report',      label: '🚨 بلاغ',             description: 'بلاغ ضد عضو أو مشكلة' },
      { id: 'complaint',   label: '📢 شكوى',             description: 'شكاوى عامة' },
      { id: 'application', label: '📋 تقديم إدارة',       description: 'التقديم لفريق الإدارة' },
    ],
  },

  // ── Protection ──
  protection: {
    antiSpam: {
      enabled: true,
      maxMessages: 7,
      timeWindow: 5000,
      action: 'mute',
      muteDuration: 5 * 60 * 1000,
    },
    antiLinks: {
      enabled: true,
      whitelist: [],
      action: 'delete',
    },
    antiRaid: {
      enabled: true,
      joinThreshold: 10,
      joinWindow: 10000,
      action: 'lockdown',
    },
    antiMention: {
      enabled: true,
      maxMentions: 5,
      action: 'mute',
    },
    newAccountThreshold: 7 * 24 * 60 * 60 * 1000, // 7 أيام
  },

  // ── Subscription Plans ──
  plans: {
    free: {
      name: 'مجاني',
      maxTickets: 3,
      maxCommands: 50,
      aiEnabled: false,
      customWelcome: false,
      advancedProtection: false,
    },
    premium: {
      name: 'Premium ⭐',
      maxTickets: 50,
      maxCommands: -1,
      aiEnabled: true,
      customWelcome: true,
      advancedProtection: true,
    },
    ultimate: {
      name: 'Ultimate 👑',
      maxTickets: -1,
      maxCommands: -1,
      aiEnabled: true,
      customWelcome: true,
      advancedProtection: true,
      priority: true,
    },
  },
};
