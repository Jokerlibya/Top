const mongoose = require('mongoose');

const ShopProductSchema = new mongoose.Schema({
  guildId:   { type: String, required: true, index: true },
  productId: { type: String, required: true },
  name:      { type: String, required: true },
  price:     { type: Number, required: true, min: 1 },
  type:      { type: String, enum: ['role', 'code', 'digital'], required: true },
  value:     { type: String, required: true },
  stock:     { type: Number, default: -1 }, // -1 = غير محدود
  createdAt: { type: Date, default: Date.now },
});

ShopProductSchema.index({ guildId: 1, productId: 1 }, { unique: true });

module.exports = mongoose.model('ShopProduct', ShopProductSchema);
