const mongoose = require('mongoose');

const GuildSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  prefix: { type: String, default: '!' },
  language: { type: String, default: 'ar' },
  plan: { type: String, enum: ['free', 'premium', 'ultimate'], default: 'free' },
  planExpiry: { type: Date, default: null },

  // ── Moderation ──
  moderation: {
    logChannelId: String,
    muteRoleId: String,
    autoModEnabled: { type: Boolean, default: true },
  },

  // ── Protection ──
  protection: {
    antiSpam:    { enabled: { type: Boolean, default: true }, action: { type: String, default: 'mute' } },
    antiLinks:   { enabled: { type: Boolean, default: false }, whitelist: [String] },
    antiRaid:    { enabled: { type: Boolean, default: true }, action: { type: String, default: 'lockdown' } },
    antiMention: { enabled: { type: Boolean, default: true }, max: { type: Number, default: 5 } },
    antiBots:    { enabled: { type: Boolean, default: false } },
    antiNewAcc:  { enabled: { type: Boolean, default: false }, days: { type: Number, default: 7 } },
  },

  // ── Welcome ──
  welcome: {
    enabled: { type: Boolean, default: false },
    channelId: String,
    message: { type: String, default: 'مرحباً {user} في سيرفر {server}! 🎉' },
    imageEnabled: { type: Boolean, default: false },
    backgroundColor: { type: String, default: '#0a0a0f' },
    textColor: { type: String, default: '#ffffff' },
    autoRoleId: String,
  },

  // ── Goodbye ──
  goodbye: {
    enabled: { type: Boolean, default: false },
    channelId: String,
    message: { type: String, default: 'وداعاً {user}، نتمنى أن تعود! 👋' },
  },

  // ── Tickets ──
  tickets: {
    enabled: { type: Boolean, default: false },
    categoryId: String,
    supportRoleId: String,
    panelChannelId: String,
    transcriptChannelId: String,
    openCount: { type: Number, default: 0 },
    totalCount: { type: Number, default: 0 },
  },

  // ── Levels ──
  levels: {
    enabled: { type: Boolean, default: true },
    channelId: String,
    rewards: [{ level: Number, roleId: String }],
    noXpChannels: [String],
    noXpRoles: [String],
  },

  // ── Suggestions ──
  suggestions: {
    enabled: { type: Boolean, default: false },
    channelId: String,
    reviewChannelId: String,
    staffRoleId: String,
  },

  // ── Applications ──
  applications: {
    enabled: { type: Boolean, default: false },
    channelId: String,
    reviewChannelId: String,
    forms: [{
      id: String,
      name: String,
      questions: [String],
    }],
  },

  // ── Stats ──
  stats: {
    totalMessages: { type: Number, default: 0 },
    totalCommands: { type: Number, default: 0 },
    memberCount: { type: Number, default: 0 },
  },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

GuildSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Guild', GuildSchema);
