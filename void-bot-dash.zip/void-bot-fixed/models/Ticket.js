const mongoose = require('mongoose');

const TicketSchema = new mongoose.Schema({
  ticketId:   { type: String, required: true, unique: true },
  guildId:    { type: String, required: true },
  userId:     { type: String, required: true },
  channelId:  { type: String, required: true },
  type:       { type: String, required: true },
  status:     { type: String, enum: ['open', 'closed', 'deleted'], default: 'open' },
  subject:    { type: String, default: 'تذكرة جديدة' },
  claimedBy:  { type: String, default: null },

  messages: [{
    author:    String,
    content:   String,
    timestamp: { type: Date, default: Date.now },
  }],

  closedBy:  { type: String, default: null },
  closedAt:  { type: Date, default: null },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Ticket', TicketSchema);
