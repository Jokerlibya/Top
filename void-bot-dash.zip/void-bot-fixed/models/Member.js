const mongoose = require('mongoose');

const MemberSchema = new mongoose.Schema({
  userId:  { type: String, required: true },
  guildId: { type: String, required: true },

  // ── Levels ──
  xp:       { type: Number, default: 0 },
  level:    { type: Number, default: 0 },
  messages: { type: Number, default: 0 },
  lastXpAt: { type: Date, default: null },

  // ── Warnings ──
  warnings: [{
    reason:    String,
    moderator: String,
    date:      { type: Date, default: Date.now },
    id:        String,
  }],

  // ── Mutes ──
  muted:      { type: Boolean, default: false },
  mutedUntil: { type: Date, default: null },

  // ── Bans ──
  banned:     { type: Boolean, default: false },
  bannedAt:   { type: Date, default: null },

  // ── Economy ──
  coins:  { type: Number, default: 0 },
  bank:   { type: Number, default: 0 },

  // ── Activity ──
  dailyMessages:  { type: Number, default: 0 },
  weeklyMessages: { type: Number, default: 0 },
  lastActive:     { type: Date, default: Date.now },

  joinedAt: { type: Date, default: Date.now },
});

MemberSchema.index({ guildId: 1, userId: 1 }, { unique: true });
MemberSchema.index({ guildId: 1, xp: -1 });

module.exports = mongoose.model('Member', MemberSchema);
