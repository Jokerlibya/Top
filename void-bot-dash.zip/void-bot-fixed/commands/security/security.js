const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Guild = require('../../models/Guild');
const Embed = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('security')
    .setDescription('إعدادات الحماية')
    .addSubcommand(s => s.setName('status').setDescription('عرض حالة أنظمة الحماية'))
    .addSubcommand(s => s.setName('antispam').setDescription('تشغيل/إيقاف Anti Spam')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل أو إيقاف').setRequired(true)))
    .addSubcommand(s => s.setName('antilinks').setDescription('تشغيل/إيقاف Anti Links')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل أو إيقاف').setRequired(true)))
    .addSubcommand(s => s.setName('antiraid').setDescription('تشغيل/إيقاف Anti Raid')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل أو إيقاف').setRequired(true)))
    .addSubcommand(s => s.setName('antimention').setDescription('تشغيل/إيقاف Anti Mention')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل أو إيقاف').setRequired(true))
      .addIntegerOption(o => o.setName('max').setDescription('الحد الأقصى للمنشنات').setMinValue(2).setMaxValue(20)))
    .addSubcommand(s => s.setName('antinewaccount').setDescription('حماية من الحسابات الجديدة')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل أو إيقاف').setRequired(true))
      .addIntegerOption(o => o.setName('days').setDescription('الحد الأدنى لعمر الحساب بالأيام').setMinValue(1).setMaxValue(30)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'status') {
      const guildData = await Guild.findOne({ guildId: interaction.guild.id });
      const p = guildData?.protection || {};

      const status = (val) => val ? '🟢 مفعل' : '🔴 معطل';

      return interaction.reply({
        embeds: [Embed.primary(
          '🛡️ حالة أنظمة الحماية',
          null,
          [
            { name: '🚫 Anti Spam',        value: status(p.antiSpam?.enabled),    inline: true },
            { name: '🔗 Anti Links',       value: status(p.antiLinks?.enabled),   inline: true },
            { name: '⚔️ Anti Raid',        value: status(p.antiRaid?.enabled),    inline: true },
            { name: '📢 Anti Mention',     value: `${status(p.antiMention?.enabled)} (حد: ${p.antiMention?.max || 5})`, inline: true },
            { name: '🤖 Anti New Account', value: `${status(p.antiNewAcc?.enabled)} (${p.antiNewAcc?.days || 7} أيام)`, inline: true },
          ]
        )],
      });
    }

    const updates = {};
    const enabled = interaction.options.getBoolean('enabled');

    if (sub === 'antispam')      updates['protection.antiSpam.enabled']    = enabled;
    if (sub === 'antilinks')     updates['protection.antiLinks.enabled']   = enabled;
    if (sub === 'antiraid')      updates['protection.antiRaid.enabled']    = enabled;
    if (sub === 'antimention') {
      updates['protection.antiMention.enabled'] = enabled;
      const max = interaction.options.getInteger('max');
      if (max) updates['protection.antiMention.max'] = max;
    }
    if (sub === 'antinewaccount') {
      updates['protection.antiNewAcc.enabled'] = enabled;
      const days = interaction.options.getInteger('days');
      if (days) updates['protection.antiNewAcc.days'] = days;
    }

    await Guild.findOneAndUpdate(
      { guildId: interaction.guild.id },
      { $set: updates },
      { upsert: true }
    );

    await interaction.reply({
      embeds: [Embed.success(`تم ${enabled ? 'تفعيل' : 'تعطيل'} نظام الحماية \`${sub}\` بنجاح.`)],
    });
  },
};
