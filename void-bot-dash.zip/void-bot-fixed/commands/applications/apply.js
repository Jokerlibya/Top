const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Guild = require('../../models/Guild');
const Embed = require('../../utils/embed');
const config = require('../../config');
const FORMS = {
  admin:   { name:'تقديم إدارة',  emoji:'👑', questions:['ما اسمك؟','كم عمرك؟','ما خبرتك في الإدارة؟','كم ساعة يومياً؟','لماذا تريد الانضمام؟'] },
  mod:     { name:'تقديم إشراف', emoji:'🛡️', questions:['ما اسمك؟','كم عمرك؟','هل لديك خبرة سابقة؟','كيف ستتعامل مع المخالفات؟','كم ساعة يومياً؟'] },
  support: { name:'تقديم دعم',   emoji:'🎧', questions:['ما اسمك؟','ما مجال خبرتك؟','هل تتحدث أكثر من لغة؟','كيف ستساعد الأعضاء؟'] },
};
module.exports = {
  data: new SlashCommandBuilder().setName('apply').setDescription('نظام التقديمات')
    .addSubcommand(s=>s.setName('admin').setDescription('تقديم إدارة'))
    .addSubcommand(s=>s.setName('mod').setDescription('تقديم إشراف'))
    .addSubcommand(s=>s.setName('support').setDescription('تقديم دعم'))
    .addSubcommand(s=>s.setName('setup').setDescription('إعداد روم التقديمات').addChannelOption(o=>o.setName('channel').setDescription('الروم').setRequired(true)))
    .addSubcommand(s=>s.setName('accept').setDescription('قبول تقديم').addStringOption(o=>o.setName('message_id').setDescription('ID الرسالة').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('السبب')))
    .addSubcommand(s=>s.setName('reject').setDescription('رفض تقديم').addStringOption(o=>o.setName('message_id').setDescription('ID الرسالة').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('السبب'))),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({embeds:[Embed.error('تحتاج صلاحية إدارة السيرفر.')],ephemeral:true});
      const ch = interaction.options.getChannel('channel');
      await Guild.findOneAndUpdate({guildId:interaction.guild.id},{$set:{'applications.enabled':true,'applications.reviewChannelId':ch.id}},{upsert:true});
      return interaction.reply({embeds:[Embed.success(`تم تعيين ${ch} روماً للتقديمات!`)]});
    }
    if (sub === 'accept' || sub === 'reject') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({embeds:[Embed.error('تحتاج صلاحية.')],ephemeral:true});
      const gd = await Guild.findOne({guildId:interaction.guild.id});
      const reviewCh = interaction.guild.channels.cache.get(gd?.applications?.reviewChannelId);
      if (!reviewCh) return interaction.reply({embeds:[Embed.error('روم التقديمات غير موجود.')],ephemeral:true});
      const msg = await reviewCh.messages.fetch(interaction.options.getString('message_id')).catch(()=>null);
      if (!msg) return interaction.reply({embeds:[Embed.error('لم أجد الرسالة.')],ephemeral:true});
      const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
      const isAccept = sub==='accept';
      await msg.edit({embeds:[EmbedBuilder.from(msg.embeds[0]).setColor(isAccept?config.colors.success:config.colors.danger).addFields({name:isAccept?'✅ مقبول':'❌ مرفوض',value:`بواسطة: ${interaction.user}\n📝 ${reason}`})],components:[]});
      const applicantId = msg.embeds[0]?.footer?.text?.match(/\d{17,20}/)?.[0];
      if (applicantId) {
        const user = await interaction.client.users.fetch(applicantId).catch(()=>null);
        if (user) user.send({embeds:[isAccept?Embed.success(`🎉 تم قبول تقديمك في **${interaction.guild.name}**!\n${reason}`):Embed.error(`❌ تم رفض تقديمك في **${interaction.guild.name}**.\n${reason}`)]}).catch(()=>{});
      }
      return interaction.reply({embeds:[Embed.success(`تم ${isAccept?'قبول':'رفض'} التقديم.`)],ephemeral:true});
    }
    const gd = await Guild.findOne({guildId:interaction.guild.id});
    if (!gd?.applications?.enabled) return interaction.reply({embeds:[Embed.warning('نظام التقديمات غير مفعل.')],ephemeral:true});
    const form = FORMS[sub];
    const modal = new ModalBuilder().setCustomId(`apply_modal_${sub}`).setTitle(`${form.emoji} ${form.name}`);
    form.questions.slice(0,5).forEach((q,i)=>modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId(`q${i}`).setLabel(q.slice(0,45)).setStyle(i===form.questions.length-1?TextInputStyle.Paragraph:TextInputStyle.Short).setRequired(true).setMaxLength(500))));
    await interaction.showModal(modal);
    const sub2 = await interaction.awaitModalSubmit({filter:i=>i.customId===`apply_modal_${sub}`&&i.user.id===interaction.user.id,time:5*60*1000}).catch(()=>null);
    if (!sub2) return;
    await sub2.deferReply({ephemeral:true});
    const answers = form.questions.slice(0,5).map((q,i)=>({name:q,value:sub2.fields.getTextInputValue(`q${i}`)}));
    const reviewCh = interaction.guild.channels.cache.get(gd.applications.reviewChannelId);
    if (!reviewCh) return sub2.editReply({embeds:[Embed.error('روم التقديمات غير مضبوط.')]});
    const embed = new EmbedBuilder().setColor(config.colors.primary).setTitle(`${form.emoji} ${form.name} — تقديم جديد`)
      .setThumbnail(interaction.user.displayAvatarURL({dynamic:true})).setDescription(`**المتقدم:** ${interaction.user}\n**التاريخ:** <t:${Math.floor(Date.now()/1000)}:F>`)
      .addFields(answers).setFooter({text:`ID المتقدم: ${interaction.user.id}`}).setTimestamp();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('apply_accept').setLabel('قبول').setStyle(ButtonStyle.Success).setEmoji('✅'),
      new ButtonBuilder().setCustomId('apply_reject').setLabel('رفض').setStyle(ButtonStyle.Danger).setEmoji('❌'));
    await reviewCh.send({embeds:[embed],components:[row]});
    await sub2.editReply({embeds:[Embed.success('تم إرسال تقديمك! سيتم مراجعته قريباً.')]});
  },
};
