const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
const QUESTIONS = [
  { q: 'ما هو أكبر كوكب في المجموعة الشمسية؟', ans: 'المشتري', opts: ['المشتري','زحل','أورانوس','نبتون'] },
  { q: 'كم عدد أيام السنة الكبيسة؟', ans: '366', opts: ['365','366','367','364'] },
  { q: 'ما هي عاصمة فرنسا؟', ans: 'باريس', opts: ['لندن','برلين','باريس','مدريد'] },
  { q: 'ما هو أسرع حيوان بري؟', ans: 'الفهد', opts: ['الأسد','الفهد','النمر','الحصان'] },
  { q: 'الرمز الكيميائي للذهب؟', ans: 'Au', opts: ['Go','Gd','Au','Ag'] },
  { q: 'من اخترع الهاتف؟', ans: 'ألكسندر بيل', opts: ['إديسون','ألكسندر بيل','نيوتن','تسلا'] },
  { q: 'كم يبلغ طول سور الصين العظيم؟', ans: '21000 كم', opts: ['5000 كم','10000 كم','21000 كم','30000 كم'] },
];
const LETTERS = ['أ','ب','ج','د'];
module.exports = {
  data: new SlashCommandBuilder().setName('trivia').setDescription('سؤال معلومات عشوائي')
    .addIntegerOption(o => o.setName('time').setDescription('وقت الإجابة بالثواني').setMinValue(10).setMaxValue(120)),
  async execute(interaction) {
    const timeLimit = (interaction.options.getInteger('time') || 30) * 1000;
    const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    const shuffled = [...q.opts].sort(() => Math.random() - 0.5);
    const answered = new Map();
    const mkEmbed = (done=false) => new EmbedBuilder().setColor(done ? 0x64748b : config.colors.primary)
      .setTitle('🧠 سؤال معلومات!').setDescription(`**${q.q}**\n\n${shuffled.map((o,i)=>`${LETTERS[i]}) ${o}`).join('\n')}`)
      .addFields({name:'👥 المجيبون',value:`\`${answered.size}\``,inline:true})
      .setFooter({text: done ? 'انتهى الوقت!' : `الوقت: ${timeLimit/1000} ثانية`}).setTimestamp();
    const mkRow = (dis=false) => new ActionRowBuilder().addComponents(shuffled.map((_,i) =>
      new ButtonBuilder().setCustomId(`tv_${i}`).setLabel(LETTERS[i]).setStyle(ButtonStyle.Secondary).setDisabled(dis)));
    const msg = await interaction.reply({ embeds:[mkEmbed()], components:[mkRow()], fetchReply:true });
    const col = msg.createMessageComponentCollector({ filter: i=>i.customId.startsWith('tv_'), time: timeLimit });
    col.on('collect', async i => {
      const idx = parseInt(i.customId.split('_')[1]);
      answered.set(i.user.id, idx);
      await i.reply({ content: `✅ اخترت: **${shuffled[idx]}**`, ephemeral:true });
      await msg.edit({ embeds:[mkEmbed()], components:[mkRow()] }).catch(()=>{});
    });
    col.on('end', async () => {
      await msg.edit({ embeds:[mkEmbed(true)], components:[mkRow(true)] }).catch(()=>{});
      const correctIdx = shuffled.findIndex(o => o === q.ans);
      const correct = [...answered.entries()].filter(([,v])=>v===correctIdx);
      interaction.channel.send({ embeds:[new EmbedBuilder().setColor(config.colors.success)
        .setTitle('📊 نتيجة السؤال').setDescription(`**السؤال:** ${q.q}\n✅ **الإجابة:** ${q.ans}`)
        .addFields({name:'✅ أجابوا صحيح',value: correct.length ? correct.map(([id])=>`<@${id}>`).join(', ').slice(0,500) : 'لا أحد'})
        .setTimestamp()] }).catch(()=>{});
    });
  },
};
