const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('wheel')
    .setDescription('عجلة حظ — اختيار عشوائي من قائمة')
    .addStringOption(o => o.setName('items').setDescription('الخيارات مفصولة بفاصلة مثل: أحمد, سالم, خالد').setRequired(true).setMaxLength(500))
    .addIntegerOption(o => o.setName('picks').setDescription('عدد الاختيارات').setMinValue(1).setMaxValue(5)),

  async execute(interaction) {
    const raw   = interaction.options.getString('items');
    const picks = interaction.options.getInteger('picks') || 1;
    const items = raw.split(',').map(i => i.trim()).filter(Boolean);

    if (items.length < 2)
      return interaction.reply({ content: '⚠️ أضف خيارين على الأقل مفصولين بفاصلة.', ephemeral: true });

    if (picks > items.length)
      return interaction.reply({ content: `⚠️ لا يمكن اختيار ${picks} من ${items.length} خيارات!`, ephemeral: true });

    await interaction.deferReply();

    // تأثير الدوران بـ edit متكررة
    const spinFrames = 5;
    for (let i = 0; i < spinFrames; i++) {
      const fake = items[Math.floor(Math.random() * items.length)];
      await interaction.editReply({ content: `🎡 **جاري الدوران...** ➜ **${fake}**` });
      await new Promise(r => setTimeout(r, 400));
    }

    // النتيجة النهائية
    const shuffled = [...items].sort(() => Math.random() - 0.5);
    const winners  = shuffled.slice(0, picks);

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('🎡 عجلة الحظ!')
      .setDescription(
        picks === 1
          ? `🏆 الفائز: **${winners[0]}**`
          : `🏆 **الفائزون:**\n${winners.map((w, i) => `${i+1}. **${w}**`).join('\n')}`
      )
      .addFields({ name: '📋 الخيارات الكاملة', value: items.join(' • ') })
      .setFooter({ text: `بواسطة: ${interaction.user.username}` })
      .setTimestamp();

    await interaction.editReply({ content: null, embeds: [embed] });
  },
};
