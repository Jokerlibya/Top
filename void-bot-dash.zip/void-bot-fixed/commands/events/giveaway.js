const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits,
  ActionRowBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');
const ms     = require('ms');
const Embed  = require('../../utils/embed');
const config = require('../../config');

const giveaways = new Map();

function pickWinners(list, n) {
  return [...list].sort(() => Math.random() - 0.5).slice(0, Math.min(n, list.length));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('نظام السحوبات')
    .addSubcommand(s => s.setName('start').setDescription('بدء سحب')
      .addStringOption(o => o.setName('prize').setDescription('الجائزة').setRequired(true))
      .addStringOption(o => o.setName('duration').setDescription('المدة: 10m, 1h, 1d').setRequired(true))
      .addIntegerOption(o => o.setName('winners').setDescription('عدد الفائزين').setRequired(true).setMinValue(1).setMaxValue(20))
      .addRoleOption(o => o.setName('role').setDescription('رتبة مطلوبة للمشاركة'))
      .addChannelOption(o => o.setName('channel').setDescription('الروم')))
    .addSubcommand(s => s.setName('end').setDescription('إنهاء سحب مبكراً')
      .addStringOption(o => o.setName('message_id').setDescription('ID رسالة السحب').setRequired(true)))
    .addSubcommand(s => s.setName('reroll').setDescription('إعادة السحب')
      .addStringOption(o => o.setName('message_id').setDescription('ID رسالة السحب').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('السحوبات الجارية'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'start') {
      const prize    = interaction.options.getString('prize');
      const durStr   = interaction.options.getString('duration');
      const winners  = interaction.options.getInteger('winners');
      const reqRole  = interaction.options.getRole('role');
      const ch       = interaction.options.getChannel('channel') || interaction.channel;
      const dur      = ms(durStr);

      if (!dur || dur < 10000 || dur > ms('30d'))
        return interaction.reply({ embeds: [Embed.error('مدة غير صالحة. مثال: 10m, 1h, 1d')], ephemeral: true });

      const endTs      = Date.now() + dur;
      const participants = new Set();

      const mkEmbed = (done = false) => new EmbedBuilder()
        .setColor(done ? 0x64748b : config.colors.primary)
        .setTitle(`🎉 ${prize}`)
        .setDescription(
          `🏆 **الفائزون:** ${winners}\n` +
          `👥 **المشاركون:** ${participants.size}\n` +
          (reqRole ? `🏷️ **الرتبة المطلوبة:** ${reqRole}\n` : '') +
          `⏰ **ينتهي:** <t:${Math.floor(endTs/1000)}:R>\n` +
          (done ? '\n🔴 **انتهى السحب!**' : '\n> اضغط 🎉 للمشاركة!')
        )
        .setFooter({ text: `بواسطة: ${interaction.user.username}` })
        .setTimestamp(endTs);

      const mkRow = (dis = false) => new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('gw_join').setLabel('المشاركة').setEmoji('🎉')
          .setStyle(ButtonStyle.Primary).setDisabled(dis)
      );

      await interaction.reply({ embeds: [Embed.success(`تم بدء السحب في ${ch}!`)], ephemeral: true });
      const msg = await ch.send({ embeds: [mkEmbed()], components: [mkRow()] });
      const data = { prize, winners, endTs, participants, reqRole: reqRole?.id, guildId: interaction.guild.id, channelId: ch.id };
      giveaways.set(msg.id, data);

      const collector = msg.createMessageComponentCollector({ filter: i => i.customId === 'gw_join', time: dur });

      collector.on('collect', async i => {
        if (data.reqRole && !i.member.roles.cache.has(data.reqRole))
          return i.reply({ content: `⚠️ تحتاج رتبة <@&${data.reqRole}> للمشاركة!`, ephemeral: true });

        if (participants.has(i.user.id)) {
          participants.delete(i.user.id);
          await i.reply({ content: '❌ تم إلغاء مشاركتك.', ephemeral: true });
        } else {
          participants.add(i.user.id);
          await i.reply({ content: '✅ تم تسجيل مشاركتك! حظاً موفقاً 🍀', ephemeral: true });
        }
        await msg.edit({ embeds: [mkEmbed()], components: [mkRow()] }).catch(() => {});
      });

      collector.on('end', async () => {
        const win = pickWinners([...participants], winners);
        await msg.edit({ embeds: [mkEmbed(true)], components: [mkRow(true)] }).catch(() => {});
        if (!win.length) {
          ch.send({ embeds: [Embed.warning(`لا يوجد فائز في سحب **${prize}**.`)] });
        } else {
          ch.send({
            content: win.map(w => `<@${w}>`).join(' '),
            embeds: [new EmbedBuilder().setColor(config.colors.success)
              .setTitle('🎉 نتيجة السحب!')
              .setDescription(`**الجائزة:** ${prize}\n**الفائزون:**\n${win.map(w => `<@${w}>`).join('\n')}`)
              .setTimestamp()],
          });
        }
        giveaways.delete(msg.id);
      });
    }

    else if (sub === 'end') {
      const id   = interaction.options.getString('message_id');
      const data = giveaways.get(id);
      if (!data) return interaction.reply({ embeds: [Embed.error('لم أجد سحباً بهذا الـ ID.')], ephemeral: true });
      const win = pickWinners([...data.participants], data.winners);
      const ch  = interaction.guild.channels.cache.get(data.channelId);
      if (win.length && ch) {
        ch.send({
          content: win.map(w => `<@${w}>`).join(' '),
          embeds: [new EmbedBuilder().setColor(config.colors.success)
            .setTitle('🎉 السحب انتهى مبكراً!')
            .setDescription(`**الجائزة:** ${data.prize}\n**الفائزون:**\n${win.map(w=>`<@${w}>`).join('\n')}`)],
        });
      }
      giveaways.delete(id);
      await interaction.reply({ embeds: [Embed.success('تم إنهاء السحب.')] });
    }

    else if (sub === 'reroll') {
      const id   = interaction.options.getString('message_id');
      const data = giveaways.get(id) || { participants: new Set(), winners: 1 };
      const win  = pickWinners([...data.participants], data.winners || 1);
      if (!win.length) return interaction.reply({ embeds: [Embed.warning('لا يوجد مشاركون.')], ephemeral: true });
      await interaction.reply({ embeds: [Embed.success(`🎉 الفائزون الجدد: ${win.map(w=>`<@${w}>`).join(', ')}`)] });
    }

    else if (sub === 'list') {
      const active = [...giveaways.values()].filter(g => g.guildId === interaction.guild.id);
      if (!active.length) return interaction.reply({ embeds: [Embed.info('لا توجد سحوبات جارية.')], ephemeral: true });
      const fields = active.map(g => ({ name: `🎉 ${g.prize}`, value: `👥 ${g.participants.size} | ⏰ <t:${Math.floor(g.endTs/1000)}:R>` }));
      return interaction.reply({ embeds: [Embed.primary(`السحوبات الجارية (${active.length})`, null, fields)], ephemeral: true });
    }
  },
};
