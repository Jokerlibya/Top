const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const modlog = require('../../systems/modlog');
const Embed  = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('إدارة رتب الأعضاء')
    .addSubcommand(s => s.setName('add').setDescription('إضافة رتبة لعضو')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('الرتبة').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('إزالة رتبة من عضو')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('الرتبة').setRequired(true)))
    .addSubcommand(s => s.setName('all').setDescription('إعطاء رتبة لجميع الأعضاء')
      .addRoleOption(o => o.setName('role').setDescription('الرتبة').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('معلومات عن رتبة')
      .addRoleOption(o => o.setName('role').setDescription('الرتبة').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ManageRoles)) return;
    const sub  = interaction.options.getSubcommand();
    const role = interaction.options.getRole('role');

    if (sub === 'add') {
      const target = interaction.options.getMember('user');
      if (!target) return interaction.reply({ embeds: [Embed.error('العضو غير موجود.')], ephemeral: true });
      if (role.position >= interaction.guild.members.me.roles.highest.position)
        return interaction.reply({ embeds: [Embed.error('الرتبة أعلى من رتبة البوت!')], ephemeral: true });
      if (target.roles.cache.has(role.id))
        return interaction.reply({ embeds: [Embed.warning('العضو يملك هذه الرتبة بالفعل.')], ephemeral: true });
      await target.roles.add(role, 'بواسطة Void Bot');
      await interaction.reply({ embeds: [Embed.success(`تم إضافة ${role} لـ ${target.user.username}.`)] });
      await modlog.log(interaction.guild, 'roleAdd', { user: target.user, moderator: interaction.user, role });
    }

    else if (sub === 'remove') {
      const target = interaction.options.getMember('user');
      if (!target) return interaction.reply({ embeds: [Embed.error('العضو غير موجود.')], ephemeral: true });
      if (!target.roles.cache.has(role.id))
        return interaction.reply({ embeds: [Embed.warning('العضو لا يملك هذه الرتبة.')], ephemeral: true });
      await target.roles.remove(role, 'بواسطة Void Bot');
      await interaction.reply({ embeds: [Embed.success(`تم إزالة ${role} من ${target.user.username}.`)] });
      await modlog.log(interaction.guild, 'roleRemove', { user: target.user, moderator: interaction.user, role });
    }

    else if (sub === 'all') {
      await interaction.deferReply();
      const members = await interaction.guild.members.fetch();
      let count = 0;
      for (const [, m] of members) {
        if (!m.user.bot && !m.roles.cache.has(role.id)) {
          await m.roles.add(role).catch(() => {});
          count++;
        }
      }
      await interaction.editReply({ embeds: [Embed.success(`تم إعطاء ${role} لـ **${count}** عضو.`)] });
    }

    else if (sub === 'info') {
      const created = Math.floor(role.createdTimestamp / 1000);
      await interaction.reply({
        embeds: [Embed.primary(`🏷️ ${role.name}`, null, [
          { name: 'ID', value: `\`${role.id}\``, inline: true },
          { name: 'اللون', value: role.hexColor, inline: true },
          { name: 'الأعضاء', value: `${role.members.size}`, inline: true },
          { name: 'الموضع', value: `#${role.position}`, inline: true },
          { name: 'تاريخ الإنشاء', value: `<t:${created}:F>`, inline: false },
        ])],
      });
    }
  },
};
