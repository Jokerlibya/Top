const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Embed = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('حذف رسائل من الروم')
    .addIntegerOption(o => o.setName('amount').setDescription('عدد الرسائل (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('حذف رسائل عضو معين فقط'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ManageMessages)) return;

    await interaction.deferReply({ ephemeral: true });

    const amount = interaction.options.getInteger('amount');
    const user   = interaction.options.getUser('user');

    let messages = await interaction.channel.messages.fetch({ limit: user ? 100 : amount });

    if (user) {
      messages = messages.filter(m => m.author.id === user.id).first(amount);
    }

    // Discord لا يسمح بحذف رسائل أكثر من 14 يوم
    const deletable = messages.filter ? 
      [...messages.values()].filter(m => Date.now() - m.createdTimestamp < 1_209_600_000) :
      messages.filter(m => Date.now() - m.createdTimestamp < 1_209_600_000);

    const deleted = await interaction.channel.bulkDelete(deletable, true).catch(() => null);

    const count = deleted?.size ?? 0;
    await interaction.editReply({
      embeds: [Embed.success(`تم حذف **${count}** رسالة${user ? ` من ${user}` : ''}.`)],
    });

    setTimeout(() => interaction.deleteReply().catch(() => {}), 5000);
  },
};
