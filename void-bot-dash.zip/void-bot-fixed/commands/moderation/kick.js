const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const modlog = require('../../systems/modlog');
const Embed  = require('../../utils/embed');
const { requirePermission, canModerate } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('طرد عضو من السيرفر')
    .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('السبب'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.KickMembers)) return;

    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';

    if (!target) return interaction.reply({ embeds: [Embed.error('العضو غير موجود.')], ephemeral: true });

    if (!canModerate(interaction.member, target)) {
      return interaction.reply({ embeds: [Embed.error('لا يمكنك طرد هذا العضو.')], ephemeral: true });
    }

    try {
      await target.user.send({
        embeds: [Embed.error(`تم طردك من **${interaction.guild.name}**\n📝 السبب: ${reason}`)],
      }).catch(() => {});

      await target.kick(`${reason} | بواسطة: ${interaction.user.tag}`);

      await interaction.reply({
        embeds: [Embed.mod({ action: 'kick', user: target.user, moderator: interaction.user, reason })],
      });

      await modlog.log(interaction.guild, 'kick', { user: target.user, moderator: interaction.user, reason });

    } catch (err) {
      interaction.reply({ embeds: [Embed.error(`فشل الطرد: ${err.message}`)], ephemeral: true });
    }
  },
};
