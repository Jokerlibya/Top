const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ms     = require('ms');
const modlog = require('../../systems/modlog');
const Embed  = require('../../utils/embed');
const { requirePermission, canModerate } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('كتم عضو مؤقتاً')
    .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('المدة مثل: 10m, 1h, 1d').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('السبب'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ModerateMembers)) return;

    const target   = interaction.options.getMember('user');
    const durStr   = interaction.options.getString('duration');
    const reason   = interaction.options.getString('reason') || 'لم يذكر سبب';
    const duration = ms(durStr);

    if (!target) return interaction.reply({ embeds: [Embed.error('العضو غير موجود.')], ephemeral: true });

    if (!duration || duration < 5000 || duration > ms('28d')) {
      return interaction.reply({ embeds: [Embed.error('مدة غير صالحة. مثال: `10m`, `1h`, `1d` (الحد الأقصى 28 يوم)')], ephemeral: true });
    }

    if (!canModerate(interaction.member, target)) {
      return interaction.reply({ embeds: [Embed.error('لا يمكنك كتم هذا العضو.')], ephemeral: true });
    }

    try {
      await target.timeout(duration, `${reason} | بواسطة: ${interaction.user.tag}`);

      await target.user.send({
        embeds: [Embed.warning(`تم كتمك في **${interaction.guild.name}** لمدة **${durStr}**\n📝 السبب: ${reason}`)],
      }).catch(() => {});

      await interaction.reply({
        embeds: [Embed.mod({ action: 'mute', user: target.user, moderator: interaction.user, reason, duration: durStr })],
      });

      await modlog.log(interaction.guild, 'mute', {
        user: target.user, moderator: interaction.user, reason, duration: durStr,
      });

    } catch (err) {
      interaction.reply({ embeds: [Embed.error(`فشل الكتم: ${err.message}`)], ephemeral: true });
    }
  },
};
