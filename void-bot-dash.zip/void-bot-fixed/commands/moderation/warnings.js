const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Member = require('../../models/Member');
const Embed  = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('عرض أو إدارة تحذيرات عضو')
    .addSubcommand(s => s.setName('list').setDescription('عرض التحذيرات')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('حذف تحذير')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
      .addStringOption(o => o.setName('id').setDescription('ID التحذير').setRequired(true)))
    .addSubcommand(s => s.setName('clear').setDescription('مسح كل التحذيرات')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getUser('user');
    const member = await Member.findOne({ userId: target.id, guildId: interaction.guild.id });

    if (sub === 'list') {
      if (!member || member.warnings.length === 0) {
        return interaction.reply({ embeds: [Embed.info(`${target.username} ليس لديه أي تحذيرات.`)] });
      }

      const fields = member.warnings.map((w, i) => ({
        name:  `#${i + 1} — ID: \`${w.id}\``,
        value: `📝 **السبب:** ${w.reason}\n👤 **المشرف:** <@${w.moderator}>\n📅 **التاريخ:** <t:${Math.floor(new Date(w.date).getTime() / 1000)}:R>`,
      }));

      return interaction.reply({
        embeds: [Embed.primary(
          `⚠️ تحذيرات ${target.username}`,
          `إجمالي: **${member.warnings.length}** تحذير`,
          fields.slice(0, 10)
        )],
      });
    }

    if (sub === 'remove') {
      const warnId = interaction.options.getString('id');
      const result = await Member.updateOne(
        { userId: target.id, guildId: interaction.guild.id },
        { $pull: { warnings: { id: warnId } } }
      );
      return interaction.reply({
        embeds: [result.modifiedCount > 0
          ? Embed.success(`تم حذف التحذير \`${warnId}\` من ${target.username}.`)
          : Embed.error(`لم يُعثر على تحذير بهذا الـ ID.`)],
      });
    }

    if (sub === 'clear') {
      await Member.updateOne(
        { userId: target.id, guildId: interaction.guild.id },
        { $set: { warnings: [] } }
      );
      return interaction.reply({ embeds: [Embed.success(`تم مسح جميع تحذيرات ${target.username}.`)] });
    }
  },
};
