const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const modlog = require('../../systems/modlog');
const Embed  = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('رفع الكتم عن عضو')
    .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('السبب'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ModerateMembers)) return;

    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';

    if (!target) return interaction.reply({ embeds: [Embed.error('العضو غير موجود.')], ephemeral: true });

    if (!target.isCommunicationDisabled()) {
      return interaction.reply({ embeds: [Embed.warning('هذا العضو غير مكتوم.')], ephemeral: true });
    }

    try {
      await target.timeout(null, `${reason} | بواسطة: ${interaction.user.tag}`);

      await interaction.reply({
        embeds: [Embed.mod({ action: 'unmute', user: target.user, moderator: interaction.user, reason })],
      });

      await target.user.send({
        embeds: [Embed.success(`تم رفع الكتم عنك في **${interaction.guild.name}**.`)],
      }).catch(() => {});

      await modlog.log(interaction.guild, 'unmute', { user: target.user, moderator: interaction.user, reason });

    } catch (err) {
      interaction.reply({ embeds: [Embed.error(`فشل رفع الكتم: ${err.message}`)], ephemeral: true });
    }
  },
};
