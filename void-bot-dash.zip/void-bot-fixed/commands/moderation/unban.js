const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Member = require('../../models/Member');
const modlog = require('../../systems/modlog');
const Embed  = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('رفع الحظر عن مستخدم')
    .addStringOption(o => o.setName('user_id').setDescription('ID المستخدم').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('سبب رفع الحظر'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.BanMembers)) return;

    const userId = interaction.options.getString('user_id');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';

    // تحقق أن الـ ID صالح
    if (!/^\d{17,20}$/.test(userId)) {
      return interaction.reply({ embeds: [Embed.error('الـ ID غير صالح.')], ephemeral: true });
    }

    try {
      const ban = await interaction.guild.bans.fetch(userId).catch(() => null);
      if (!ban) {
        return interaction.reply({ embeds: [Embed.error('هذا المستخدم غير محظور.')], ephemeral: true });
      }

      await interaction.guild.members.unban(userId, `${reason} | بواسطة: ${interaction.user.tag}`);

      await Member.updateOne(
        { userId, guildId: interaction.guild.id },
        { $set: { banned: false } }
      );

      await interaction.reply({
        embeds: [Embed.mod({
          action:    'unban',
          user:      ban.user,
          moderator: interaction.user,
          reason,
        })],
      });

      await modlog.log(interaction.guild, 'unban', {
        user:      ban.user,
        moderator: interaction.user,
        reason,
      });

    } catch (err) {
      interaction.reply({ embeds: [Embed.error(`فشل رفع الحظر: ${err.message}`)], ephemeral: true });
    }
  },
};
