const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Embed = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('قفل أو فتح روم')
    .addSubcommand(s => s.setName('channel').setDescription('قفل الروم الحالي')
      .addStringOption(o => o.setName('reason').setDescription('السبب')))
    .addSubcommand(s => s.setName('unlock').setDescription('فتح الروم الحالي')
      .addStringOption(o => o.setName('reason').setDescription('السبب')))
    .addSubcommand(s => s.setName('server').setDescription('⚠️ قفل جميع رومات السيرفر (طوارئ)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ManageChannels)) return;

    const sub    = interaction.options.getSubcommand();
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const everyone = interaction.guild.roles.everyone;

    await interaction.deferReply();

    if (sub === 'channel') {
      await interaction.channel.permissionOverwrites.edit(everyone, { SendMessages: false });
      await interaction.editReply({
        embeds: [Embed.warning(`🔒 تم قفل ${interaction.channel}\n📝 السبب: ${reason}`)],
      });
    }

    else if (sub === 'unlock') {
      await interaction.channel.permissionOverwrites.edit(everyone, { SendMessages: null });
      await interaction.editReply({
        embeds: [Embed.success(`🔓 تم فتح ${interaction.channel}\n📝 السبب: ${reason}`)],
      });
    }

    else if (sub === 'server') {
      const channels = interaction.guild.channels.cache.filter(c => c.isTextBased());
      let count = 0;
      for (const [, ch] of channels) {
        await ch.permissionOverwrites.edit(everyone, { SendMessages: false }).catch(() => {});
        count++;
      }
      await interaction.editReply({
        embeds: [Embed.warning(`🔒 تم قفل **${count}** روم في السيرفر بسبب الطوارئ!`)],
      });
    }
  },
};
