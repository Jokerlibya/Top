const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Member  = require('../../models/Member');
const modlog  = require('../../systems/modlog');
const Embed   = require('../../utils/embed');
const config  = require('../../config');
const { requirePermission } = require('../../utils/permissions');
const { nanoid } = (() => { try { return require('nanoid'); } catch { return { nanoid: () => Math.random().toString(36).slice(2, 8).toUpperCase() }; } })();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('تحذير عضو')
    .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('السبب').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ModerateMembers)) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const warnId = Math.random().toString(36).slice(2, 8).toUpperCase();

    let member = await Member.findOneAndUpdate(
      { userId: target.id, guildId: interaction.guild.id },
      { $push: { warnings: { reason, moderator: interaction.user.id, id: warnId } } },
      { upsert: true, new: true }
    );

    const warnCount = member.warnings.length;

    await target.send({
      embeds: [Embed.warning(`تلقيت تحذيراً في **${interaction.guild.name}**\n📝 السبب: ${reason}\n⚠️ عدد تحذيراتك: ${warnCount}`)],
    }).catch(() => {});

    await interaction.reply({
      embeds: [Embed.mod({ action: 'warn', user: target, moderator: interaction.user, reason, caseId: warnId })],
    });

    // حظر تلقائي عند الحد الأقصى
    if (config.mod.autobanOnMaxWarns && warnCount >= config.mod.maxWarnings) {
      await interaction.guild.members.ban(target.id, { reason: `تجاوز الحد الأقصى من التحذيرات (${warnCount})` }).catch(() => {});
      await interaction.followUp({
        embeds: [Embed.danger(`تم حظر ${target.tag} تلقائياً بعد ${warnCount} تحذيرات! 🔨`)],
      });
    }

    await modlog.log(interaction.guild, 'warn', { user: target, moderator: interaction.user, reason, caseId: warnId });
  },
};
