const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Member  = require('../../models/Member');
const modlog  = require('../../systems/modlog');
const Embed   = require('../../utils/embed');
const { requirePermission, canModerate } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('حظر عضو من السيرفر')
    .addUserOption(o => o.setName('user').setDescription('العضو المراد حظره').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('سبب الحظر'))
    .addIntegerOption(o => o.setName('days').setDescription('حذف رسائل (0-7 أيام)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.BanMembers)) return;

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
    const days   = interaction.options.getInteger('days') ?? 0;
    const member = interaction.guild.members.cache.get(target.id);

    if (member) {
      if (!canModerate(interaction.member, member)) {
        return interaction.reply({ embeds: [Embed.error('لا يمكنك حظر هذا العضو! رتبته أعلى من رتبتك.')], ephemeral: true });
      }
    }

    try {
      await interaction.guild.members.ban(target.id, {
        reason: `${reason} | بواسطة: ${interaction.user.tag}`,
        deleteMessageSeconds: days * 86400,
      });

      // DM للمستخدم قبل الحظر
      await target.send({
        embeds: [Embed.error(`تم حظرك من **${interaction.guild.name}**\n📝 السبب: ${reason}`)],
      }).catch(() => {});

      await Member.updateOne(
        { userId: target.id, guildId: interaction.guild.id },
        { banned: true, bannedAt: new Date() },
        { upsert: true }
      );

      await interaction.reply({
        embeds: [Embed.mod({
          action:    'ban',
          user:      target,
          moderator: interaction.user,
          reason,
        })],
      });

      await modlog.log(interaction.guild, 'ban', {
        user:      target,
        moderator: interaction.user,
        reason,
      });

    } catch (err) {
      interaction.reply({ embeds: [Embed.error(`فشل الحظر: ${err.message}`)], ephemeral: true });
    }
  },
};
