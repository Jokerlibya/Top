const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Embed = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('تفعيل أو تعطيل السلو مود')
    .addIntegerOption(o => o.setName('seconds').setDescription('المدة بالثواني (0 للإيقاف)').setRequired(true).setMinValue(0).setMaxValue(21600))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ManageChannels)) return;

    const secs = interaction.options.getInteger('seconds');
    await interaction.channel.setRateLimitPerUser(secs, `بواسطة: ${interaction.user.tag}`);

    if (secs === 0) {
      await interaction.reply({ embeds: [Embed.success(`تم إيقاف السلو مود في ${interaction.channel}.`)] });
    } else {
      await interaction.reply({ embeds: [Embed.warning(`تم تفعيل السلو مود: رسالة كل **${secs}** ثانية في ${interaction.channel}.`)] });
    }
  },
};
