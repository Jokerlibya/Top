const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
module.exports = {
  data: new SlashCommandBuilder().setName('guess').setDescription('تخمين الرقم (1-100)')
    .addIntegerOption(o=>o.setName('max').setDescription('الحد الأقصى للرقم').setMinValue(10).setMaxValue(1000)),
  async execute(interaction) {
    const max = interaction.options.getInteger('max') || 100;
    const secret = Math.floor(Math.random()*max)+1;
    let attempts = 0;
    const maxAttempts = Math.ceil(Math.log2(max))+2;
    const guesses = [];
    await interaction.reply({embeds:[new EmbedBuilder().setColor(config.colors.primary).setTitle('🎯 تخمين الرقم!').setDescription(`فكرت برقم بين **1** و **${max}**\nلديك **${maxAttempts}** محاولة!\n\nاكتب رقمك في الروم:`).setTimestamp()]});
    const col = interaction.channel.createMessageCollector({filter:m=>m.author.id===interaction.user.id&&!isNaN(m.content)&&parseInt(m.content)>=1&&parseInt(m.content)<=max,time:60000,max:maxAttempts});
    col.on('collect', async m => {
      const guess = parseInt(m.content);
      attempts++;
      guesses.push(guess);
      m.delete().catch(()=>{});
      if (guess===secret) {
        col.stop('win');
        return interaction.followUp({embeds:[new EmbedBuilder().setColor(config.colors.success).setTitle('🎉 صحيح!').setDescription(`الرقم كان **${secret}**!\nوجدته في **${attempts}** محاولة!`).addFields({name:'محاولاتك',value:guesses.join(' ← ')}).setTimestamp()]});
      }
      const rem = maxAttempts-attempts;
      const hint = guess<secret ? '⬆️ أكبر' : '⬇️ أصغر';
      if (rem>0) interaction.followUp({embeds:[new EmbedBuilder().setColor(config.colors.warning).setDescription(`${hint} من **${guess}** | تبقى لك **${rem}** محاولة`)],ephemeral:true});
    });
    col.on('end',(_,r)=>{ if(r!=='win'&&r!=='user') interaction.followUp({embeds:[new EmbedBuilder().setColor(config.colors.danger).setTitle('❌ انتهت المحاولات!').setDescription(`الرقم كان **${secret}**!\nمحاولاتك: ${guesses.join(' ← ')}`)]}); });
  },
};
