const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
const CHOICES = { rock:'🪨 حجر', paper:'📄 ورقة', scissors:'✂️ مقص' };
const WINS = { rock:'scissors', paper:'rock', scissors:'paper' };
module.exports = {
  data: new SlashCommandBuilder().setName('rps').setDescription('حجر ورقة مقص')
    .addUserOption(o=>o.setName('opponent').setDescription('تحدي عضو (اتركه للعب مع البوت)')),
  async execute(interaction) {
    const opponent = interaction.options.getMember('opponent');
    const vsBot = !opponent || opponent.user.id === interaction.user.id;
    const p1 = interaction.user;
    let p1Choice = null, p2Choice = null;
    const mkRow = (dis=false) => new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('rps_rock').setEmoji('🪨').setLabel('حجر').setStyle(ButtonStyle.Secondary).setDisabled(dis),
      new ButtonBuilder().setCustomId('rps_paper').setEmoji('📄').setLabel('ورقة').setStyle(ButtonStyle.Secondary).setDisabled(dis),
      new ButtonBuilder().setCustomId('rps_scissors').setEmoji('✂️').setLabel('مقص').setStyle(ButtonStyle.Secondary).setDisabled(dis),
    );
    const embed = () => new EmbedBuilder().setColor(config.colors.primary).setTitle('🎮 حجر ورقة مقص!')
      .setDescription(vsBot ? `${p1} تلعب ضد البوت!\nاختر:` : `${p1} vs ${opponent.user}\n${p1.username}: ${p1Choice?CHOICES[p1Choice]:'⏳'} | ${opponent.user.username}: ${p2Choice?CHOICES[p2Choice]:'⏳'}`);
    const msg = await interaction.reply({ embeds:[embed()], components:[mkRow()], fetchReply:true });
    const filter = vsBot ? i=>i.user.id===p1.id : i=>[p1.id,opponent.user.id].includes(i.user.id);
    const col = msg.createMessageComponentCollector({ filter, time:30000 });
    col.on('collect', async i => {
      const choice = i.customId.split('_')[1];
      if (i.user.id === p1.id && !p1Choice) p1Choice = choice;
      else if (!vsBot && i.user.id === opponent.user.id && !p2Choice) p2Choice = choice;
      else return i.reply({content:'انتظر دورك!',ephemeral:true});
      await i.update({ embeds:[embed()], components:[mkRow()] });
      if (vsBot || (p1Choice && p2Choice)) col.stop('done');
    });
    col.on('end', async (_, reason) => {
      if (reason !== 'done' && !p1Choice) return msg.edit({embeds:[new EmbedBuilder().setColor(0x64748b).setTitle('⏰ انتهى الوقت!')],components:[]});
      if (vsBot) p2Choice = Object.keys(CHOICES)[Math.floor(Math.random()*3)];
      let result;
      if (p1Choice === p2Choice) result = '🤝 تعادل!';
      else if (WINS[p1Choice] === p2Choice) result = vsBot ? `🏆 ${p1.username} فاز!` : `🏆 ${p1.username} فاز!`;
      else result = vsBot ? '🤖 البوت فاز!' : `🏆 ${opponent.user.username} فاز!`;
      await msg.edit({embeds:[new EmbedBuilder().setColor(config.colors.success).setTitle('🎮 النتيجة!')
        .addFields({name:p1.username,value:CHOICES[p1Choice],inline:true},{name:vsBot?'البوت':opponent.user.username,value:CHOICES[p2Choice],inline:true},{name:'النتيجة',value:result})
        .setTimestamp()],components:[mkRow(true)]}).catch(()=>{});
    });
  },
};
