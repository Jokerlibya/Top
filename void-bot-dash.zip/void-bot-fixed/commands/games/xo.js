const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');
const WIN_COMBOS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
module.exports = {
  data: new SlashCommandBuilder().setName('xo').setDescription('لعبة إكس أو مع عضو آخر')
    .addUserOption(o=>o.setName('opponent').setDescription('المنافس').setRequired(true)),
  async execute(interaction) {
    const p1 = interaction.user;
    const p2Member = interaction.options.getMember('opponent');
    if (!p2Member || p2Member.user.id === p1.id || p2Member.user.bot)
      return interaction.reply({content:'⚠️ اختر عضواً آخر للمنافسة.',ephemeral:true});
    const p2 = p2Member.user;
    const board = Array(9).fill(null);
    let turn = p1.id;
    const symbols = {[p1.id]:'❌',[p2.id]:'⭕'};
    const checkWin = (sym) => WIN_COMBOS.some(c=>c.every(i=>board[i]===sym));
    const isDraw = () => board.every(c=>c!==null);
    const mkRows = (dis=false) => {
      const rows = [];
      for (let r=0;r<3;r++) {
        const row = new ActionRowBuilder();
        for (let c=0;c<3;c++) {
          const idx=r*3+c;
          row.addComponents(new ButtonBuilder().setCustomId(`xo_${idx}`).setLabel(board[idx]||'·').setStyle(board[idx]==='❌'?ButtonStyle.Danger:board[idx]==='⭕'?ButtonStyle.Primary:ButtonStyle.Secondary).setDisabled(dis||board[idx]!==null));
        }
        rows.push(row);
      }
      return rows;
    };
    const mkEmbed = (msg='') => new EmbedBuilder().setColor(config.colors.primary).setTitle('🎮 إكس أو')
      .setDescription(`${p1} ❌ vs ⭕ ${p2}\n\n${msg||`دور: ${turn===p1.id?p1.username:p2.username} ${symbols[turn]}`}`);
    const msg = await interaction.reply({embeds:[mkEmbed()],components:mkRows(),fetchReply:true});
    const col = msg.createMessageComponentCollector({filter:i=>i.customId.startsWith('xo_')&&[p1.id,p2.id].includes(i.user.id),time:120000});
    col.on('collect', async i => {
      if (i.user.id!==turn) return i.reply({content:'⚠️ ليس دورك!',ephemeral:true});
      const idx=parseInt(i.customId.split('_')[1]);
      board[idx]=symbols[turn];
      if (checkWin(symbols[turn])) { col.stop('win'); return i.update({embeds:[mkEmbed(`🏆 **${turn===p1.id?p1.username:p2.username} فاز!**`)],components:mkRows(true)}); }
      if (isDraw()) { col.stop('draw'); return i.update({embeds:[mkEmbed('🤝 **تعادل!**')],components:mkRows(true)}); }
      turn = turn===p1.id?p2.id:p1.id;
      await i.update({embeds:[mkEmbed()],components:mkRows()});
    });
    col.on('end',(_,r)=>{ if(r==='time') msg.edit({embeds:[mkEmbed('⏰ انتهى الوقت!')],components:mkRows(true)}).catch(()=>{}); });
  },
};
