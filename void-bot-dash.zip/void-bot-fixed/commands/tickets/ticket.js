const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Tickets = require('../../systems/tickets');
const Ticket  = require('../../models/Ticket');
const Guild   = require('../../models/Guild');
const Embed   = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('نظام التذاكر')
    .addSubcommand(s => s.setName('panel').setDescription('إنشاء بانيل التذاكر في الروم الحالي'))
    .addSubcommand(s => s.setName('setup').setDescription('إعداد نظام التذاكر')
      .addChannelOption(o => o.setName('category').setDescription('الكاتيجوري لإنشاء التذاكر فيه'))
      .addRoleOption(o => o.setName('support').setDescription('رتبة الدعم'))
      .addChannelOption(o => o.setName('transcript').setDescription('روم الترانسكريبت')))
    .addSubcommand(s => s.setName('list').setDescription('عرض التذاكر المفتوحة'))
    .addSubcommand(s => s.setName('add').setDescription('إضافة عضو للتذكرة')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('إزالة عضو من التذكرة')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'panel') {
      if (!await requirePermission(interaction, PermissionFlagsBits.ManageChannels)) return;
      await interaction.deferReply({ ephemeral: true });
      const guildData = await Guild.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { $setOnInsert: { guildId: interaction.guild.id } },
        { upsert: true, new: true }
      );
      await Tickets.createPanel(interaction.channel, guildData);
      await interaction.editReply({ embeds: [Embed.success('تم إنشاء بانيل التذاكر!')] });
    }

    else if (sub === 'setup') {
      if (!await requirePermission(interaction, PermissionFlagsBits.ManageGuild)) return;
      await interaction.deferReply({ ephemeral: true });

      const category   = interaction.options.getChannel('category');
      const support    = interaction.options.getRole('support');
      const transcript = interaction.options.getChannel('transcript');

      const update = { 'tickets.enabled': true };
      if (category)   update['tickets.categoryId']          = category.id;
      if (support)    update['tickets.supportRoleId']        = support.id;
      if (transcript) update['tickets.transcriptChannelId']  = transcript.id;

      await Guild.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { $set: update },
        { upsert: true }
      );

      await interaction.editReply({ embeds: [Embed.success('تم إعداد نظام التذاكر!')] });
    }

    else if (sub === 'list') {
      const tickets = await Ticket.find({ guildId: interaction.guild.id, status: 'open' }).lean();
      if (!tickets.length) return interaction.reply({ embeds: [Embed.info('لا توجد تذاكر مفتوحة.')], ephemeral: true });

      const fields = tickets.map(t => ({
        name:  `🎫 ${t.ticketId}`,
        value: `<@${t.userId}> • ${t.type} • <#${t.channelId}>`,
      }));

      return interaction.reply({
        embeds: [Embed.primary(`🎫 التذاكر المفتوحة (${tickets.length})`, null, fields.slice(0, 10))],
        ephemeral: true,
      });
    }

    else if (sub === 'add') {
      const user   = interaction.options.getUser('user');
      const ticket = await Ticket.findOne({ channelId: interaction.channel.id });
      if (!ticket) return interaction.reply({ embeds: [Embed.error('هذا الروم ليس تذكرة.')], ephemeral: true });

      await interaction.channel.permissionOverwrites.edit(user.id, {
        ViewChannel: true, SendMessages: true,
      });
      await interaction.reply({ embeds: [Embed.success(`تم إضافة ${user} للتذكرة.`)] });
    }

    else if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.delete(user.id);
      await interaction.reply({ embeds: [Embed.success(`تم إزالة ${user} من التذكرة.`)] });
    }
  },
};
