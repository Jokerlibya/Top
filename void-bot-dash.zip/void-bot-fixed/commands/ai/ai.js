const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios  = require('axios');
const Guild  = require('../../models/Guild');
const Embed  = require('../../utils/embed');
const config = require('../../config');

const PROMPTS = {
  announce: (text) => `اكتب إعلاناً احترافياً وجذاباً بالعربية لسيرفر ديسكورد عن: "${text}". اجعله قصيراً ومؤثراً مع إيموجيات مناسبة.`,
  rules:    (text) => `اكتب قوانين سيرفر ديسكورد احترافية بالعربية لسيرفر: "${text}". اجعلها واضحة ومرتبة ومرقمة.`,
  summary:  (text) => `لخص النص التالي بالعربية بشكل مختصر وواضح: "${text}"`,
  translate:(text) => `ترجم النص التالي إلى العربية: "${text}"`,
  ideas:    (text) => `اقترح 5 أفكار إبداعية بالعربية لسيرفر ديسكورد عن موضوع: "${text}". اجعل كل فكرة مختصرة.`,
  names:    (text) => `اقترح 10 أسماء إبداعية بالعربية لسيرفر ديسكورد في مجال: "${text}". اجعل الأسماء قصيرة وجذابة.`,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('🤖 نظام الذكاء الاصطناعي')
    .addSubcommand(s => s.setName('announce').setDescription('كتابة إعلان')
      .addStringOption(o => o.setName('topic').setDescription('موضوع الإعلان').setRequired(true)))
    .addSubcommand(s => s.setName('rules').setDescription('كتابة قوانين')
      .addStringOption(o => o.setName('server').setDescription('اسم أو وصف السيرفر').setRequired(true)))
    .addSubcommand(s => s.setName('summary').setDescription('تلخيص نص')
      .addStringOption(o => o.setName('text').setDescription('النص المراد تلخيصه').setRequired(true).setMaxLength(2000)))
    .addSubcommand(s => s.setName('translate').setDescription('ترجمة نص')
      .addStringOption(o => o.setName('text').setDescription('النص المراد ترجمته').setRequired(true).setMaxLength(1000)))
    .addSubcommand(s => s.setName('ideas').setDescription('اقتراح أفكار لسيرفر')
      .addStringOption(o => o.setName('topic').setDescription('مجال السيرفر').setRequired(true)))
    .addSubcommand(s => s.setName('names').setDescription('اقتراح أسماء')
      .addStringOption(o => o.setName('field').setDescription('المجال').setRequired(true))),

  async execute(interaction) {
    // تحقق من الخطة
    const guildData = await Guild.findOne({ guildId: interaction.guild.id });
    if (guildData?.plan === 'free') {
      return interaction.reply({
        embeds: [Embed.warning('نظام الذكاء الاصطناعي متاح فقط لأعضاء **Premium** و **Ultimate**!\nرقّ خطتك من /premium')],
        ephemeral: true,
      });
    }

    if (!process.env.OPENAI_KEY) {
      return interaction.reply({
        embeds: [Embed.error('مفتاح OpenAI API غير مضاف في إعدادات البوت.')],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const sub   = interaction.options.getSubcommand();
    const input = interaction.options.getString('topic')
               || interaction.options.getString('text')
               || interaction.options.getString('server')
               || interaction.options.getString('field');

    const prompt = PROMPTS[sub]?.(input);
    if (!prompt) return interaction.editReply({ embeds: [Embed.error('أمر غير معروف.')] });

    try {
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'أنت مساعد ذكي لسيرفرات ديسكورد العربية.' },
            { role: 'user',   content: prompt },
          ],
          max_tokens:  800,
          temperature: 0.8,
        },
        {
          headers: {
            Authorization: `Bearer ${process.env.OPENAI_KEY}`,
            'Content-Type': 'application/json',
          },
          timeout: 30000,
        }
      );

      const result = response.data.choices[0].message.content.trim();

      const titles = {
        announce: '📢 الإعلان',
        rules:    '📜 القوانين',
        summary:  '📝 الملخص',
        translate:'🌍 الترجمة',
        ideas:    '💡 الأفكار',
        names:    '🏷️ الأسماء',
      };

      const embed = new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle(`🤖 ${titles[sub] || 'النتيجة'}`)
        .setDescription(result.slice(0, 2000))
        .setFooter({ text: `Void AI • GPT-3.5 • طلبك: ${input.slice(0, 50)}` })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });

    } catch (err) {
      const msg = err.response?.data?.error?.message || err.message;
      await interaction.editReply({ embeds: [Embed.error(`فشل الاتصال بـ AI: ${msg}`)] });
    }
  },
};
