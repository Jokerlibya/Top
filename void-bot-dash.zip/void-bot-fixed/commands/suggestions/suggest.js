const {
  SlashCommandBuilder, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits
} = require('discord.js');
const Guild  = require('../../models/Guild');
const Embed  = require('../../utils/embed');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('نظام الاقتراحات')
    .addSubcommand(s => s.setName('send').setDescription('إرسال اقتراح')
      .addStringOption(o => o.setName('text').setDescription('اكتب اقتراحك').setRequired(true).setMaxLength(1000)))
    .addSubcommand(s => s.setName('setup').setDescription('إعداد روم الاقتراحات')
      .addChannelOption(o => o.setName('channel').setDescription('الروم').setRequired(true)))
    .addSubcommand(s => s.setName('accept').setDescription('قبول اقتراح')
      .addStringOption(o => o.setName('message_id').setDescription('ID الرسالة').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('السبب')))
    .addSubcommand(s => s.setName('reject').setDescription('رفض اقتراح')
      .addStringOption(o => o.setName('message_id').setDescription('ID الرسالة').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('السبب'))),

  async execute(interaction) {
    const sub       = interaction.options.getSubcommand();
    const guildData = await Guild.findOne({ guildId: interaction.guild.id });

    if (sub === 'send') {
      if (!guildData?.suggestions?.enabled || !guildData?.suggestions?.channelId) {
        return interaction.reply({ embeds: [Embed.error('نظام الاقتراحات غير مفعل في هذا السيرفر.')], ephemeral: true });
      }

      const text    = interaction.options.getString('text');
      const channel = interaction.guild.channels.cache.get(guildData.suggestions.channelId);
      if (!channel) return interaction.reply({ embeds: [Embed.error('روم الاقتراحات غير موجود.')], ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle('💡 اقتراح جديد')
        .setDescription(text)
        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
        .addFields(
          { name: '👍 موافق', value: '`0`', inline: true },
          { name: '👎 لا أوافق', value: '`0`', inline: true },
          { name: '📊 الحالة', value: '⏳ قيد المراجعة', inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `ID: ${interaction.user.id}` });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('suggest_yes').setLabel('موافق').setStyle(ButtonStyle.Success).setEmoji('👍'),
        new ButtonBuilder().setCustomId('suggest_no').setLabel('لا أوافق').setStyle(ButtonStyle.Danger).setEmoji('👎'),
      );

      const msg = await channel.send({ embeds: [embed], components: [row] });
      await msg.react('👍').catch(() => {});
      await msg.react('👎').catch(() => {});

      return interaction.reply({ embeds: [Embed.success(`تم إرسال اقتراحك! ${channel}`)], ephemeral: true });
    }

    else if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
      }
      const ch = interaction.options.getChannel('channel');
      await Guild.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { $set: { 'suggestions.enabled': true, 'suggestions.channelId': ch.id } },
        { upsert: true }
      );
      return interaction.reply({ embeds: [Embed.success(`تم تعيين ${ch} روماً للاقتراحات!`)] });
    }

    else if (sub === 'accept' || sub === 'reject') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
        return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة الرسائل.')], ephemeral: true });
      }

      const msgId  = interaction.options.getString('message_id');
      const reason = interaction.options.getString('reason') || 'لم يذكر سبب';
      const isAccept = sub === 'accept';

      const channel = guildData?.suggestions?.channelId
        ? interaction.guild.channels.cache.get(guildData.suggestions.channelId)
        : null;

      if (!channel) return interaction.reply({ embeds: [Embed.error('روم الاقتراحات غير موجود.')], ephemeral: true });

      const msg = await channel.messages.fetch(msgId).catch(() => null);
      if (!msg) return interaction.reply({ embeds: [Embed.error('لم يتم العثور على الرسالة.')], ephemeral: true });

      const oldEmbed  = msg.embeds[0];
      const newStatus = isAccept ? '✅ تم القبول' : '❌ تم الرفض';

      const newEmbed = EmbedBuilder.from(oldEmbed)
        .setColor(isAccept ? config.colors.success : config.colors.danger)
        .spliceFields(2, 1, { name: '📊 الحالة', value: newStatus, inline: true })
        .addFields({ name: isAccept ? '✅ تم القبول بواسطة' : '❌ تم الرفض بواسطة', value: `${interaction.user}\n📝 ${reason}`, inline: false });

      await msg.edit({ embeds: [newEmbed], components: [] });
      await interaction.reply({ embeds: [Embed.success(`تم ${isAccept ? 'قبول' : 'رفض'} الاقتراح.`)], ephemeral: true });
    }
  },
};
