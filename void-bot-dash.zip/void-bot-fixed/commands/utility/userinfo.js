const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Member = require('../../models/Member');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('معلومات تفصيلية عن عضو')
    .addUserOption(o => o.setName('user').setDescription('العضو (اتركه فارغاً لمعلوماتك)')),

  async execute(interaction) {
    const target  = interaction.options.getMember('user') || interaction.member;
    const user    = target.user;
    const created = Math.floor(user.createdTimestamp / 1000);
    const joined  = Math.floor(target.joinedTimestamp / 1000);

    const memberData = await Member.findOne({ userId: user.id, guildId: interaction.guild.id });

    const roles = target.roles.cache
      .filter(r => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position)
      .map(r => `${r}`)
      .slice(0, 10)
      .join(', ') || 'لا توجد رتب';

    const badges = [];
    const flags  = user.flags?.toArray() || [];
    if (flags.includes('Staff'))                  badges.push('👨‍💼 موظف ديسكورد');
    if (flags.includes('HypeSquadOnlineHouse1'))  badges.push('<:bravery:> HypeSquad Bravery');
    if (flags.includes('ActiveDeveloper'))        badges.push('👨‍💻 مطور نشط');
    if (target.premiumSince)                      badges.push('💎 Server Booster');

    const embed = new EmbedBuilder()
      .setColor(target.displayHexColor || config.colors.primary)
      .setTitle(`${user.username}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🆔 الـ ID',          value: `\`${user.id}\``,                  inline: true  },
        { name: '🤖 بوت؟',            value: user.bot ? 'نعم' : 'لا',           inline: true  },
        { name: '📅 إنشاء الحساب',    value: `<t:${created}:F>\n<t:${created}:R>`, inline: false },
        { name: '📥 الانضمام للسيرفر',value: `<t:${joined}:F>\n<t:${joined}:R>`, inline: false },
        { name: `🏷️ الرتب (${target.roles.cache.size - 1})`, value: roles.slice(0, 500), inline: false },
      )
      .setFooter({ text: `Void Bot • ${interaction.guild.name}` })
      .setTimestamp();

    if (memberData) {
      embed.addFields(
        { name: '⭐ المستوى',         value: `\`${memberData.level}\``,                   inline: true },
        { name: '💜 XP',              value: `\`${memberData.xp.toLocaleString()}\``,     inline: true },
        { name: '💬 الرسائل',         value: `\`${memberData.messages.toLocaleString()}\``, inline: true },
        { name: '⚠️ التحذيرات',       value: `\`${memberData.warnings.length}\``,          inline: true },
      );
    }

    if (badges.length) embed.addFields({ name: '🏅 الشارات', value: badges.join('\n'), inline: false });

    await interaction.reply({ embeds: [embed] });
  },
};
