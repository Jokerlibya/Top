const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('إنشاء تصويت')
    .addStringOption(o => o.setName('question').setDescription('سؤال التصويت').setRequired(true).setMaxLength(256))
    .addStringOption(o => o.setName('option1').setDescription('الخيار الأول').setRequired(true))
    .addStringOption(o => o.setName('option2').setDescription('الخيار الثاني').setRequired(true))
    .addStringOption(o => o.setName('option3').setDescription('الخيار الثالث (اختياري)'))
    .addStringOption(o => o.setName('option4').setDescription('الخيار الرابع (اختياري)'))
    .addIntegerOption(o => o.setName('duration').setDescription('مدة التصويت بالدقائق (0 = بلا حد)').setMinValue(0).setMaxValue(1440)),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const duration = interaction.options.getInteger('duration') || 0;

    const options = [
      interaction.options.getString('option1'),
      interaction.options.getString('option2'),
      interaction.options.getString('option3'),
      interaction.options.getString('option4'),
    ].filter(Boolean);

    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
    const votes  = new Array(options.length).fill(0);
    const voters = new Set();

    const buildEmbed = (ended = false) => {
      const total = votes.reduce((a, b) => a + b, 0);
      const desc = options.map((opt, i) => {
        const pct = total ? Math.round((votes[i] / total) * 100) : 0;
        const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
        return `${emojis[i]} **${opt}**\n\`${bar}\` ${pct}% (${votes[i]})`;
      }).join('\n\n');

      return new EmbedBuilder()
        .setColor(ended ? config.colors.secondary : config.colors.primary)
        .setTitle(`📊 ${question}`)
        .setDescription(desc)
        .addFields(
          { name: '👥 المصوتون', value: `\`${voters.size}\``, inline: true },
          { name: '⏱️ الحالة', value: ended ? '🔴 انتهى' : (duration ? `ينتهي خلال ${duration} دقيقة` : '🟢 جاري'), inline: true },
        )
        .setFooter({ text: `بواسطة: ${interaction.user.username}` })
        .setTimestamp();
    };

    const buildRow = (disabled = false) => new ActionRowBuilder().addComponents(
      ...options.map((_, i) =>
        new ButtonBuilder()
          .setCustomId(`poll_vote_${i}`)
          .setLabel(options[i].slice(0, 20))
          .setEmoji(emojis[i])
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(disabled)
      )
    );

    const msg = await interaction.reply({
      embeds: [buildEmbed()],
      components: [buildRow()],
      fetchReply: true,
    });

    // جمع الأصوات
    const collector = msg.createMessageComponentCollector({
      filter: i => i.customId.startsWith('poll_vote_'),
      time:   duration ? duration * 60 * 1000 : 24 * 60 * 60 * 1000,
    });

    collector.on('collect', async i => {
      const idx = parseInt(i.customId.split('_')[2]);
      if (voters.has(i.user.id)) {
        return i.reply({ content: '⚠️ صوّتت مسبقاً!', ephemeral: true });
      }
      voters.add(i.user.id);
      votes[idx]++;
      await i.update({ embeds: [buildEmbed()], components: [buildRow()] });
    });

    collector.on('end', async () => {
      await msg.edit({ embeds: [buildEmbed(true)], components: [buildRow(true)] }).catch(() => {});
    });
  },
};
