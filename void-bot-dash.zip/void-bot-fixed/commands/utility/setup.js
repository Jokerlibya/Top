const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Guild = require('../../models/Guild');
const Embed = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('إعداد البوت في السيرفر')
    .addSubcommand(s => s.setName('welcome').setDescription('إعداد رسائل الترحيب')
      .addChannelOption(o => o.setName('channel').setDescription('روم الترحيب').setRequired(true).addChannelTypes(ChannelType.GuildText))
      .addRoleOption(o => o.setName('autorole').setDescription('رتبة تلقائية للأعضاء الجدد'))
      .addStringOption(o => o.setName('message').setDescription('رسالة الترحيب (استخدم {user} و {server} و {count})')))
    .addSubcommand(s => s.setName('logs').setDescription('تعيين روم سجل الإدارة')
      .addChannelOption(o => o.setName('channel').setDescription('الروم').setRequired(true).addChannelTypes(ChannelType.GuildText)))
    .addSubcommand(s => s.setName('levels').setDescription('إعداد نظام الليفل')
      .addBooleanOption(o => o.setName('enabled').setDescription('تشغيل/إيقاف').setRequired(true))
      .addChannelOption(o => o.setName('channel').setDescription('روم إشعارات اللفل أب')))
    .addSubcommand(s => s.setName('prefix').setDescription('تغيير البريفكس')
      .addStringOption(o => o.setName('prefix').setDescription('البريفكس الجديد').setRequired(true).setMaxLength(5)))
    .addSubcommand(s => s.setName('view').setDescription('عرض إعدادات السيرفر الحالية'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'welcome') {
      const channel  = interaction.options.getChannel('channel');
      const autorole = interaction.options.getRole('autorole');
      const message  = interaction.options.getString('message');

      const update = {
        'welcome.enabled':   true,
        'welcome.channelId': channel.id,
      };
      if (autorole) update['welcome.autoRoleId'] = autorole.id;
      if (message)  update['welcome.message']    = message;

      await Guild.findOneAndUpdate({ guildId: interaction.guild.id }, { $set: update }, { upsert: true });

      return interaction.reply({
        embeds: [Embed.success(
          `تم إعداد روم الترحيب: ${channel}${autorole ? `\nالرتبة التلقائية: ${autorole}` : ''}`
        )],
      });
    }

    if (sub === 'logs') {
      const channel = interaction.options.getChannel('channel');
      await Guild.findOneAndUpdate(
        { guildId: interaction.guild.id },
        { $set: { 'moderation.logChannelId': channel.id } },
        { upsert: true }
      );
      return interaction.reply({ embeds: [Embed.success(`تم تعيين ${channel} روماً للسجلات!`)] });
    }

    if (sub === 'levels') {
      const enabled = interaction.options.getBoolean('enabled');
      const channel = interaction.options.getChannel('channel');
      const update  = { 'levels.enabled': enabled };
      if (channel) update['levels.channelId'] = channel.id;

      await Guild.findOneAndUpdate({ guildId: interaction.guild.id }, { $set: update }, { upsert: true });

      return interaction.reply({
        embeds: [Embed.success(`تم ${enabled ? 'تفعيل' : 'تعطيل'} نظام الليفل!${channel ? `\nروم الإشعارات: ${channel}` : ''}`)],
      });
    }

    if (sub === 'prefix') {
      const prefix = interaction.options.getString('prefix');
      await Guild.findOneAndUpdate({ guildId: interaction.guild.id }, { $set: { prefix } }, { upsert: true });
      return interaction.reply({ embeds: [Embed.success(`تم تغيير البريفكس إلى: \`${prefix}\``)] });
    }

    if (sub === 'view') {
      const data = await Guild.findOne({ guildId: interaction.guild.id });
      if (!data) return interaction.reply({ embeds: [Embed.info('لا توجد إعدادات محفوظة. استخدم /setup لإعداد البوت.')] });

      return interaction.reply({
        embeds: [Embed.primary(
          `⚙️ إعدادات ${interaction.guild.name}`,
          null,
          [
            { name: '📌 البريفكس', value: `\`${data.prefix || '!'}\``, inline: true },
            { name: '💎 الخطة',   value: data.plan,                    inline: true },
            { name: '🌍 اللغة',   value: data.language,                inline: true },
            { name: '📥 الترحيب', value: data.welcome?.enabled ? `<#${data.welcome.channelId}>` : '❌ معطل', inline: true },
            { name: '📊 الليفل',  value: data.levels?.enabled ? '✅ مفعل' : '❌ معطل',                        inline: true },
            { name: '🎫 التذاكر', value: data.tickets?.enabled ? '✅ مفعل' : '❌ معطل',                       inline: true },
            { name: '🛡️ السجلات', value: data.moderation?.logChannelId ? `<#${data.moderation.logChannelId}>` : '❌ لم يُعين', inline: true },
          ]
        )],
      });
    }
  },
};
