const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const mongoose = require('mongoose');
const config   = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('عرض حالة البوت والـ latency'),

  async execute(interaction, client) {
    const sent = await interaction.reply({ content: '⏳ جاري القياس...', fetchReply: true });
    const ping = sent.createdTimestamp - interaction.createdTimestamp;
    const ws   = client.ws.ping;
    const db   = mongoose.connection.readyState === 1 ? '🟢 متصل' : '🔴 منقطع';

    const bar = (ms) => {
      if (ms < 100) return '🟢 ممتاز';
      if (ms < 200) return '🟡 جيد';
      return '🔴 بطيء';
    };

    await interaction.editReply({
      content: null,
      embeds: [new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle('🌌 Void Bot — الحالة')
        .addFields(
          { name: '📡 Bot Latency', value: `\`${ping}ms\` ${bar(ping)}`,  inline: true },
          { name: '💓 WS Heartbeat',value: `\`${ws}ms\` ${bar(ws)}`,      inline: true },
          { name: '🗄️ قاعدة البيانات', value: db,                         inline: true },
          { name: '⏱️ Uptime',      value: `<t:${Math.floor((Date.now() - client.uptime) / 1000)}:R>`, inline: true },
          { name: '🏠 السيرفرات',   value: `\`${client.guilds.cache.size}\``,  inline: true },
          { name: '👥 الأعضاء',     value: `\`${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()}\``, inline: true },
        )
        .setFooter({ text: `Void Bot v1.0.0` })
        .setTimestamp()],
    });
  },
};
