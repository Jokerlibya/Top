const { SlashCommandBuilder } = require('discord.js');
const ms    = require('ms');
const Embed = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminder')
    .setDescription('ضبط تذكير')
    .addStringOption(o => o.setName('time').setDescription('المدة مثل: 10m, 1h, 1d').setRequired(true))
    .addStringOption(o => o.setName('text').setDescription('نص التذكير').setRequired(true).setMaxLength(500)),

  async execute(interaction) {
    const timeStr  = interaction.options.getString('time');
    const text     = interaction.options.getString('text');
    const duration = ms(timeStr);

    if (!duration || duration < 10000 || duration > ms('7d')) {
      return interaction.reply({ embeds: [Embed.error('مدة غير صالحة. مثال: `10m`, `1h`, `2d` (الحد الأقصى 7 أيام)')], ephemeral: true });
    }

    const endTime = Math.floor((Date.now() + duration) / 1000);

    await interaction.reply({
      embeds: [Embed.success(`تم ضبط التذكير!\n📝 **${text}**\n⏰ سيُرسل <t:${endTime}:R>`)],
      ephemeral: true,
    });

    setTimeout(async () => {
      interaction.user.send({
        embeds: [Embed.primary(
          '⏰ تذكير!',
          `> ${text}\n\nضبطته في: ${interaction.guild?.name || 'DM'} <t:${Math.floor((endTime * 1000 - duration) / 1000)}:R>`
        )],
      }).catch(async () => {
        // لو DM مغلق، أرسله في الروم الأصلي
        const ch = interaction.channel;
        if (ch) {
          ch.send({
            content: `${interaction.user}`,
            embeds: [Embed.primary('⏰ تذكير!', `> ${text}`)],
          }).catch(() => {});
        }
      });
    }, duration);
  },
};
