const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Member = require('../../models/Member');
const Guild  = require('../../models/Guild');
const Ticket = require('../../models/Ticket');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('إحصائيات تفصيلية للسيرفر'),

  async execute(interaction) {
    await interaction.deferReply();

    const { guild } = interaction;
    const guildData = await Guild.findOne({ guildId: guild.id });

    const totalMembers   = guild.memberCount;
    const bots           = guild.members.cache.filter(m => m.user.bot).size;
    const humans         = totalMembers - bots;
    const onlineCount    = guild.members.cache.filter(m => m.presence?.status !== 'offline' && !m.user.bot).size;
    const openTickets    = await Ticket.countDocuments({ guildId: guild.id, status: 'open' });
    const totalTickets   = await Ticket.countDocuments({ guildId: guild.id });
    const totalMessages  = guildData?.stats?.totalMessages || 0;
    const totalWarnings  = await Member.aggregate([
      { $match: { guildId: guild.id } },
      { $project: { count: { $size: '$warnings' } } },
      { $group: { _id: null, total: { $sum: '$count' } } },
    ]);

    // أكثر الأعضاء تفاعلاً
    const topMembers = await Member.find({ guildId: guild.id })
      .sort({ messages: -1 }).limit(3).lean();

    const topList = topMembers.map((m, i) =>
      `${['🥇','🥈','🥉'][i]} <@${m.userId}> — \`${m.messages.toLocaleString()}\` رسالة`
    ).join('\n') || 'لا توجد بيانات';

    // أكثر الرومات نشاطاً (نظرياً — يحتاج إضافة عداد منفصل لكل روم)
    const textChannels = guild.channels.cache.filter(c => c.isTextBased()).size;

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`📊 إحصائيات ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: '👥 إجمالي الأعضاء',   value: `\`${totalMembers.toLocaleString()}\``,             inline: true },
        { name: '👤 بشر',               value: `\`${humans.toLocaleString()}\``,                   inline: true },
        { name: '🤖 بوتات',             value: `\`${bots}\``,                                      inline: true },
        { name: '🟢 أونلاين (تقريباً)', value: `\`${onlineCount.toLocaleString()}\``,              inline: true },
        { name: '💬 إجمالي الرسائل',    value: `\`${totalMessages.toLocaleString()}\``,            inline: true },
        { name: '📝 الرومات',            value: `\`${textChannels}\``,                             inline: true },
        { name: '🎫 التذاكر المفتوحة',  value: `\`${openTickets}\` / \`${totalTickets}\` إجمالي`, inline: true },
        { name: '⚠️ إجمالي التحذيرات',  value: `\`${totalWarnings[0]?.total || 0}\``,             inline: true },
        { name: '🏷️ الرتب',             value: `\`${guild.roles.cache.size - 1}\``,               inline: true },
        { name: '🏆 أكثر الأعضاء تفاعلاً', value: topList, inline: false },
      )
      .setFooter({ text: `Void Bot • آخر تحديث` })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  },
};
