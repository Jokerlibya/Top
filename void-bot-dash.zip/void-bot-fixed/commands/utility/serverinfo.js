const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const config = require('../../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('معلومات تفصيلية عن السيرفر'),

  async execute(interaction) {
    const { guild } = interaction;
    await guild.fetch();

    const owner   = await guild.fetchOwner();
    const roles   = guild.roles.cache.size - 1;
    const bots    = guild.members.cache.filter(m => m.user.bot).size;
    const humans  = guild.memberCount - bots;
    const created = Math.floor(guild.createdTimestamp / 1000);

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
      .setImage(guild.bannerURL({ size: 1024 }) || null)
      .addFields(
        { name: '👑 المالك',       value: `${owner.user.tag}`,                         inline: true },
        { name: '🆔 الـ ID',       value: `\`${guild.id}\``,                           inline: true },
        { name: '📅 تاريخ الإنشاء',value: `<t:${created}:F>`,                         inline: false },
        { name: '👥 الأعضاء',      value: `👤 ${humans} بشر • 🤖 ${bots} بوت`,        inline: true },
        { name: '📝 الرومات',      value: `${guild.channels.cache.size}`,              inline: true },
        { name: '🏷️ الرتب',        value: `${roles}`,                                 inline: true },
        { name: '😄 الإيموجيات',   value: `${guild.emojis.cache.size}`,               inline: true },
        { name: '🔒 التحقق',       value: guild.verificationLevel.toString(),          inline: true },
        { name: '🚀 Boost',        value: `Level ${guild.premiumTier} (${guild.premiumSubscriptionCount})`, inline: true },
      )
      .setFooter({ text: `Void Bot • ${interaction.guild.name}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
