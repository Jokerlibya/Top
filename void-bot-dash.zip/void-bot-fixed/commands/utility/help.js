const {
  SlashCommandBuilder, EmbedBuilder,
  ActionRowBuilder, StringSelectMenuBuilder
} = require('discord.js');
const config = require('../../config');

const categories = {
  moderation:  { label: '🛡️ الإدارة',         description: 'ban، kick، mute، warn، clear، lock' },
  security:    { label: '🔒 الحماية',          description: 'anti-spam، anti-links، anti-raid' },
  tickets:     { label: '🎫 التذاكر',          description: 'إنشاء وإدارة تذاكر الدعم' },
  levels:      { label: '⭐ الليفل',           description: 'rank، leaderboard، نظام XP' },
  suggestions: { label: '💡 الاقتراحات',       description: 'إرسال وإدارة الاقتراحات' },
  utility:     { label: '🔧 الأدوات',          description: 'معلومات، إحصائيات، إعدادات' },
  ai:          { label: '🤖 الذكاء الاصطناعي', description: 'كتابة، تلخيص، ترجمة' },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('قائمة أوامر Void Bot')
    .addStringOption(o => o.setName('category').setDescription('الفئة').addChoices(
      ...Object.entries(categories).map(([k, v]) => ({ name: v.label, value: k }))
    )),

  async execute(interaction, client) {
    const cat = interaction.options.getString('category');

    if (!cat) {
      // القائمة الرئيسية
      const embed = new EmbedBuilder()
        .setColor(config.colors.primary)
        .setTitle('🌌 Void Bot — قائمة الأوامر')
        .setDescription('اختر فئة من القائمة أدناه لعرض الأوامر المتاحة.')
        .addFields(
          Object.entries(categories).map(([, v]) => ({
            name:  v.label,
            value: v.description,
            inline: true,
          }))
        )
        .addFields({ name: '\u200b', value: `إجمالي الأوامر: **${client.commands.size}**`, inline: false })
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({ text: 'Void Bot v1.0.0 • /help [فئة]' })
        .setTimestamp();

      const select = new StringSelectMenuBuilder()
        .setCustomId('help_category')
        .setPlaceholder('اختر فئة...')
        .addOptions(
          Object.entries(categories).map(([k, v]) => ({
            label:       v.label,
            value:       k,
            description: v.description,
          }))
        );

      return interaction.reply({
        embeds: [embed],
        components: [new ActionRowBuilder().addComponents(select)],
      });
    }

    // عرض أوامر الفئة
    const commands = [...client.commands.values()].filter(c => {
      const path = c.data?.name;
      return true; // يمكن تصفية حسب الكاتيجوري إذا أضفت خاصية category لكل أمر
    });

    const catInfo = categories[cat];
    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`${catInfo.label} — الأوامر`)
      .setDescription(catInfo.description)
      .setFooter({ text: 'استخدم /command للمزيد من المعلومات' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },

  // Select menu handler
  async handleSelect(interaction, client) {
    if (interaction.customId !== 'help_category') return;
    const cat     = interaction.values[0];
    const catInfo = categories[cat];

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`${catInfo.label}`)
      .setDescription(catInfo.description)
      .setFooter({ text: 'Void Bot' })
      .setTimestamp();

    await interaction.update({ embeds: [embed] });
  },
};
