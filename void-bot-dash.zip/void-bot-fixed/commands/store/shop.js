const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Embed = require('../../utils/embed');
const config = require('../../config');
const Member = require('../../models/Member');
const ShopProduct = require('../../models/ShopProduct');

module.exports = {
  data: new SlashCommandBuilder().setName('shop').setDescription('نظام المتجر')
    .addSubcommand(s => s.setName('view').setDescription('عرض المتجر'))
    .addSubcommand(s => s.setName('buy').setDescription('شراء منتج')
      .addStringOption(o => o.setName('id').setDescription('ID المنتج').setRequired(true)))
    .addSubcommand(s => s.setName('add').setDescription('إضافة منتج (إداري)')
      .addStringOption(o => o.setName('name').setDescription('اسم المنتج').setRequired(true))
      .addIntegerOption(o => o.setName('price').setDescription('السعر بالعملات').setRequired(true).setMinValue(1))
      .addStringOption(o => o.setName('type').setDescription('النوع').setRequired(true)
        .addChoices(
          { name: 'رتبة', value: 'role' },
          { name: 'كود', value: 'code' },
          { name: 'رقمي', value: 'digital' }
        ))
      .addStringOption(o => o.setName('value').setDescription('ID الرتبة أو قيمة المنتج').setRequired(true))
      .addIntegerOption(o => o.setName('stock').setDescription('الكمية (-1 = غير محدود)').setMinValue(-1)))
    .addSubcommand(s => s.setName('remove').setDescription('حذف منتج (إداري)')
      .addStringOption(o => o.setName('id').setDescription('ID المنتج').setRequired(true)))
    .addSubcommand(s => s.setName('balance').setDescription('رصيدك من العملات')
      .addUserOption(o => o.setName('user').setDescription('عضو آخر'))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const gid = interaction.guild.id;

    // ── عرض المتجر ──────────────────────────────────
    if (sub === 'view') {
      const products = await ShopProduct.find({ guildId: gid });
      if (!products.length) {
        return interaction.reply({ embeds: [Embed.info('المتجر فارغ حالياً.')], ephemeral: true });
      }
      const fields = products.slice(0, 10).map(p => ({
        name: `${p.type === 'role' ? '🏷️' : p.type === 'code' ? '🔑' : '📦'} ${p.name} — \`${p.productId}\``,
        value: `💰 السعر: **${p.price}** عملة | 📦 الكمية: ${p.stock === -1 ? '∞' : p.stock}`,
      }));
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(config.colors.primary)
            .setTitle(`🛒 متجر ${interaction.guild.name}`)
            .addFields(fields)
            .setFooter({ text: 'استخدم /shop buy <id> للشراء' })
            .setTimestamp(),
        ],
      });
    }

    // ── شراء منتج ───────────────────────────────────
    if (sub === 'buy') {
      const pid = interaction.options.getString('id').toUpperCase();
      const product = await ShopProduct.findOne({ guildId: gid, productId: pid });
      if (!product) {
        return interaction.reply({ embeds: [Embed.error('المنتج غير موجود.')], ephemeral: true });
      }
      if (product.stock === 0) {
        return interaction.reply({ embeds: [Embed.error('المنتج نفد من المخزون!')], ephemeral: true });
      }

      // جلب أو إنشاء بيانات العضو
      let memberData = await Member.findOne({ guildId: gid, userId: interaction.user.id });
      if (!memberData) {
        memberData = await Member.create({ guildId: gid, userId: interaction.user.id });
      }

      if (memberData.coins < product.price) {
        return interaction.reply({
          embeds: [Embed.error(`رصيدك غير كافٍ!\nالرصيد: **${memberData.coins}** | السعر: **${product.price}**`)],
          ephemeral: true,
        });
      }

      // خصم العملات
      await Member.updateOne(
        { guildId: gid, userId: interaction.user.id },
        { $inc: { coins: -product.price } }
      );

      // تطبيق الرتبة إن كان النوع role
      if (product.type === 'role') {
        const role = interaction.guild.roles.cache.get(product.value);
        if (role) await interaction.member.roles.add(role).catch(() => {});
      }

      // تقليل الكمية إن لم تكن غير محدودة
      if (product.stock !== -1) {
        await ShopProduct.updateOne({ guildId: gid, productId: pid }, { $inc: { stock: -1 } });
      }

      // إرسال فاتورة للعضو
      await interaction.user.send({
        embeds: [
          new EmbedBuilder()
            .setColor(config.colors.success)
            .setTitle('🛒 فاتورة شراء')
            .addFields(
              { name: 'المنتج', value: product.name, inline: true },
              { name: 'السعر', value: `${product.price} عملة`, inline: true },
              { name: 'القيمة', value: product.type === 'code' ? `\`${product.value}\`` : 'تم تطبيقه', inline: false }
            )
            .setTimestamp(),
        ],
      }).catch(() => {});

      return interaction.reply({
        embeds: [Embed.success(`تم شراء **${product.name}** بنجاح! تحقق من رسائلك الخاصة.`)],
        ephemeral: true,
      });
    }

    // ── إضافة منتج ──────────────────────────────────
    if (sub === 'add') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
      }
      const pid = Math.random().toString(36).slice(2, 8).toUpperCase();
      await ShopProduct.create({
        guildId: gid,
        productId: pid,
        name:  interaction.options.getString('name'),
        price: interaction.options.getInteger('price'),
        type:  interaction.options.getString('type'),
        value: interaction.options.getString('value'),
        stock: interaction.options.getInteger('stock') ?? -1,
      });
      return interaction.reply({
        embeds: [Embed.success(`تم إضافة المنتج بـ ID: \`${pid}\``)],
        ephemeral: true,
      });
    }

    // ── حذف منتج ────────────────────────────────────
    if (sub === 'remove') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [Embed.error('تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
      }
      const pid = interaction.options.getString('id').toUpperCase();
      const deleted = await ShopProduct.findOneAndDelete({ guildId: gid, productId: pid });
      if (!deleted) {
        return interaction.reply({ embeds: [Embed.error('المنتج غير موجود.')], ephemeral: true });
      }
      return interaction.reply({
        embeds: [Embed.success(`تم حذف المنتج \`${pid}\`.`)],
        ephemeral: true,
      });
    }

    // ── الرصيد ──────────────────────────────────────
    if (sub === 'balance') {
      const target = interaction.options.getUser('user') || interaction.user;
      const memberData = await Member.findOne({ guildId: gid, userId: target.id });
      const balance = memberData?.coins ?? 0;
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(config.colors.primary)
            .setTitle('💰 الرصيد')
            .setDescription(`${target} يمتلك **${balance.toLocaleString()}** عملة`)
            .setTimestamp(),
        ],
      });
    }
  },
};
