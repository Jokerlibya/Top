const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getRank, xpForLevel } = require('../../systems/leveling');
const Embed = require('../../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('عرض مستواك أو مستوى عضو آخر')
    .addUserOption(o => o.setName('user').setDescription('العضو (اختياري)')),

  async execute(interaction) {
    await interaction.deferReply();

    const target = interaction.options.getUser('user') || interaction.user;
    const { rank, member, total } = await getRank(target.id, interaction.guild.id);

    if (!member) {
      return interaction.editReply({ embeds: [Embed.info(`${target.username} لم يبدأ بجمع XP بعد.`)] });
    }

    const xpNeeded = xpForLevel(member.level);
    const progress = Math.floor((member.xp / xpNeeded) * 20);
    const bar      = '█'.repeat(progress) + '░'.repeat(20 - progress);
    const percent  = Math.floor((member.xp / xpNeeded) * 100);

    const embed = Embed.primary(
      null,
      null,
      [
        { name: '📊 الترتيب',    value: `\`#${rank}\` من ${total}`,                     inline: true },
        { name: '⭐ المستوى',    value: `\`${member.level}\``,                           inline: true },
        { name: '✉️ الرسائل',   value: `\`${member.messages.toLocaleString()}\``,       inline: true },
        { name: `💜 XP — ${percent}%`, value: `\`${bar}\`\n\`${member.xp} / ${xpNeeded} XP\``, inline: false },
      ]
    )
    .setAuthor({ name: target.username, iconURL: target.displayAvatarURL({ dynamic: true }) })
    .setThumbnail(target.displayAvatarURL({ dynamic: true, size: 128 }));

    await interaction.editReply({ embeds: [embed] });
  },
};
