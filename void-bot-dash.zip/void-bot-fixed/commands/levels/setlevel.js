const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const Member = require('../../models/Member');
const { xpForLevel } = require('../../systems/leveling');
const Embed  = require('../../utils/embed');
const { requirePermission } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlevel')
    .setDescription('تعديل مستوى عضو (إداري)')
    .addSubcommand(s => s.setName('set').setDescription('تحديد مستوى معين')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
      .addIntegerOption(o => o.setName('level').setDescription('المستوى').setRequired(true).setMinValue(0).setMaxValue(500)))
    .addSubcommand(s => s.setName('addxp').setDescription('إضافة XP')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('الكمية').setRequired(true).setMinValue(1)))
    .addSubcommand(s => s.setName('reset').setDescription('إعادة تصفير مستوى عضو')
      .addUserOption(o => o.setName('user').setDescription('العضو').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    if (!await requirePermission(interaction, PermissionFlagsBits.ManageGuild)) return;

    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getUser('user');

    if (sub === 'set') {
      const level = interaction.options.getInteger('level');
      await Member.findOneAndUpdate(
        { userId: target.id, guildId: interaction.guild.id },
        { $set: { level, xp: 0, messages: 0 } },
        { upsert: true }
      );
      return interaction.reply({ embeds: [Embed.success(`تم تحديد مستوى ${target.username} إلى **${level}**.`)] });
    }

    if (sub === 'addxp') {
      const amount = interaction.options.getInteger('amount');
      const member = await Member.findOneAndUpdate(
        { userId: target.id, guildId: interaction.guild.id },
        { $inc: { xp: amount } },
        { upsert: true, new: true }
      );
      return interaction.reply({ embeds: [Embed.success(`تم إضافة **${amount} XP** لـ ${target.username}. المجموع: ${member.xp} XP`)] });
    }

    if (sub === 'reset') {
      await Member.findOneAndUpdate(
        { userId: target.id, guildId: interaction.guild.id },
        { $set: { level: 0, xp: 0, messages: 0 } },
        { upsert: true }
      );
      return interaction.reply({ embeds: [Embed.success(`تم إعادة تصفير مستوى ${target.username}.`)] });
    }
  },
};
