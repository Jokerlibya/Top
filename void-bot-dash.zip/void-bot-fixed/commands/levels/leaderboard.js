const { SlashCommandBuilder } = require('discord.js');
const { getLeaderboard, xpForLevel } = require('../../systems/leveling');
const Embed = require('../../utils/embed');

const medals = ['🥇', '🥈', '🥉'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('لوحة متصدري الليفل')
    .addIntegerOption(o => o.setName('top').setDescription('عدد الأعضاء (5-25)').setMinValue(5).setMaxValue(25)),

  async execute(interaction) {
    await interaction.deferReply();

    const limit   = interaction.options.getInteger('top') || 10;
    const members = await getLeaderboard(interaction.guild.id, limit);

    if (!members.length) {
      return interaction.editReply({ embeds: [Embed.info('لا توجد بيانات ليفل بعد.')] });
    }

    const description = members.map((m, i) => {
      const icon    = medals[i] || `\`#${i + 1}\``;
      const xpNeeded = xpForLevel(m.level);
      return `${icon} <@${m.userId}> — **المستوى ${m.level}** | \`${m.xp}/${xpNeeded} XP\` | 💬 ${m.messages.toLocaleString()}`;
    }).join('\n');

    await interaction.editReply({
      embeds: [Embed.primary(
        `👑 لوحة المتصدرين — ${interaction.guild.name}`,
        description
      ).setThumbnail(interaction.guild.iconURL({ dynamic: true }))],
    });
  },
};
