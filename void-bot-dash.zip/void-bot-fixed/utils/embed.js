const { EmbedBuilder } = require('discord.js');
const config = require('../config');

const Embed = {
  // Embed أساسي بلون البنفسجي
  primary(title, description, fields = []) {
    const e = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTimestamp();
    if (title)       e.setTitle(title);
    if (description) e.setDescription(description);
    if (fields.length) e.addFields(fields);
    return e;
  },

  // نجاح ✅
  success(description, title = null) {
    const e = new EmbedBuilder()
      .setColor(config.colors.success)
      .setDescription(`${config.emojis.success} ${description}`)
      .setTimestamp();
    if (title) e.setTitle(title);
    return e;
  },

  // خطأ ❌
  error(description, title = null) {
    const e = new EmbedBuilder()
      .setColor(config.colors.danger)
      .setDescription(`${config.emojis.error} ${description}`)
      .setTimestamp();
    if (title) e.setTitle(title);
    return e;
  },

  // تحذير ⚠️
  warning(description, title = null) {
    const e = new EmbedBuilder()
      .setColor(config.colors.warning)
      .setDescription(`${config.emojis.warning} ${description}`)
      .setTimestamp();
    if (title) e.setTitle(title);
    return e;
  },

  // معلومات
  info(description, title = null) {
    const e = new EmbedBuilder()
      .setColor(config.colors.info)
      .setDescription(`ℹ️ ${description}`)
      .setTimestamp();
    if (title) e.setTitle(title);
    return e;
  },

  // Embed إدارة
  mod({ action, user, moderator, reason, duration = null, caseId = null }) {
    const colors = {
      ban:    config.colors.danger,
      kick:   config.colors.warning,
      mute:   config.colors.warning,
      warn:   config.colors.warning,
      unmute: config.colors.success,
      unban:  config.colors.success,
    };

    const emojis = {
      ban:    config.emojis.ban,
      kick:   config.emojis.kick,
      mute:   config.emojis.mute,
      warn:   config.emojis.warn,
      unmute: '🔊',
      unban:  '🔓',
    };

    const e = new EmbedBuilder()
      .setColor(colors[action] || config.colors.primary)
      .setTitle(`${emojis[action] || '⚡'} ${action.toUpperCase()}`)
      .addFields(
        { name: '👤 المستخدم', value: `${user.tag || user}\n\`${user.id || user}\``, inline: true },
        { name: '🛡️ المشرف', value: `${moderator.tag || moderator}`, inline: true },
        { name: '📝 السبب', value: reason || 'لم يذكر سبب', inline: false },
      )
      .setThumbnail(user.displayAvatarURL?.() || null)
      .setTimestamp();

    if (duration) e.addFields({ name: '⏱️ المدة', value: duration, inline: true });
    if (caseId)   e.setFooter({ text: `Case #${caseId}` });

    return e;
  },

  // Embed الليفل
  levelUp(user, level, guild) {
    return new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`${config.emojis.star} لفل أب!`)
      .setDescription(`مبروك ${user}! وصلت للمستوى **${level}** 🎉`)
      .setThumbnail(user.displayAvatarURL?.({ dynamic: true }) || null)
      .setTimestamp();
  },
};

module.exports = Embed;
