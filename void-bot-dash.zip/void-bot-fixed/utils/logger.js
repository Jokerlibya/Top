const chalk = require('chalk');

const timestamp = () => new Date().toLocaleTimeString('ar-SA', { hour12: false });

const Logger = {
  info:    (...args) => console.log(chalk.cyan(`[${timestamp()}] [INFO]`), ...args),
  success: (...args) => console.log(chalk.green(`[${timestamp()}] [✓]`), ...args),
  warn:    (...args) => console.log(chalk.yellow(`[${timestamp()}] [WARN]`), ...args),
  error:   (...args) => console.log(chalk.red(`[${timestamp()}] [ERROR]`), ...args),
  debug:   (...args) => process.env.NODE_ENV === 'development' && console.log(chalk.gray(`[${timestamp()}] [DEBUG]`), ...args),
  cmd:     (...args) => console.log(chalk.magenta(`[${timestamp()}] [CMD]`), ...args),
  event:   (...args) => console.log(chalk.blue(`[${timestamp()}] [EVENT]`), ...args),
  db:      (...args) => console.log(chalk.yellow(`[${timestamp()}] [DB]`), ...args),

  void() {
    console.log(chalk.hex('#7c3aed')(`
 ██╗   ██╗ ██████╗ ██╗██████╗ 
 ██║   ██║██╔═══██╗██║██╔══██╗
 ██║   ██║██║   ██║██║██║  ██║
 ╚██╗ ██╔╝██║   ██║██║██║  ██║
  ╚████╔╝ ╚██████╔╝██║██████╔╝
   ╚═══╝   ╚═════╝ ╚═╝╚═════╝ 
`));
    console.log(chalk.hex('#a78bfa')(' Ultimate All-in-One Discord Bot v1.0.0\n'));
  }
};

module.exports = Logger;
