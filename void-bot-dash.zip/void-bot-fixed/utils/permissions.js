const { PermissionFlagsBits } = require('discord.js');
const Embed = require('./embed');

// التحقق من صلاحيات المستخدم
function checkPermissions(member, ...permissions) {
  return permissions.every(p => member.permissions.has(p));
}

// التحقق من صلاحيات البوت
function checkBotPermissions(guild, ...permissions) {
  const botMember = guild.members.cache.get(guild.client.user.id);
  return permissions.every(p => botMember?.permissions.has(p));
}

// Middleware للأوامر — يُستخدم داخل execute()
async function requirePermission(interaction, ...permissions) {
  const missing = permissions.filter(p => !interaction.member.permissions.has(p));
  if (missing.length > 0) {
    const names = missing.map(p =>
      Object.keys(PermissionFlagsBits).find(k => PermissionFlagsBits[k] === p) || p
    );
    await interaction.reply({
      embeds: [Embed.error(`ليس لديك صلاحية: \`${names.join(', ')}\``)],
      ephemeral: true,
    });
    return false;
  }
  return true;
}

// التحقق من رتبة المستخدم مقارنة بالهدف
function canModerate(moderator, target) {
  if (target.id === target.guild.ownerId) return false;
  if (moderator.id === target.guild.ownerId) return true;
  return moderator.roles.highest.comparePositionTo(target.roles.highest) > 0;
}

module.exports = { checkPermissions, checkBotPermissions, requirePermission, canModerate };
