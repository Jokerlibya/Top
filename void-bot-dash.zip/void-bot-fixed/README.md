# 🌌 Void Bot

**Ultimate All-in-One Discord Bot** — بوت ديسكورد شامل يجمع كل شيء في مكان واحد.

---

## 🚀 التثبيت والتشغيل

### المتطلبات
- **Node.js** v18.0.0 أو أحدث
- **MongoDB** (محلي أو Atlas)
- **Discord Bot Token**

### الخطوات

```bash
# 1. استنسخ المشروع
git clone https://github.com/yourname/void-bot
cd void-bot

# 2. ثبّت الحزم
npm install

# 3. انسخ ملف الإعدادات
cp .env.example .env

# 4. عدّل .env بمعلوماتك
nano .env

# 5. شغّل البوت
npm start

# أو في وضع التطوير
npm run dev

# 6. شغّل الداشبورد (في نافذة منفصلة)
npm run dashboard
```

---

## ⚙️ إعداد ملف `.env`

```env
TOKEN=your_bot_token_here
CLIENT_ID=your_client_id_here

# MongoDB — محلي أو Atlas
MONGO_URI=mongodb://localhost:27017/voidbot
# MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/voidbot

PREFIX=!
OPENAI_KEY=your_openai_key_here   # مطلوب لنظام AI
OWNER_ID=your_discord_id_here

# ── الداشبورد ──────────────────────────────────────
DASHBOARD_PORT=3000

# إذا كنت تشغّل محلياً اتركه localhost
# إذا عندك دومين اكتبه مثل: dashboard.mysite.com
DASHBOARD_HOST=localhost
```

---

## 🌐 الداشبورد

الداشبورد يعمل على Express ويعرض ملف `void-dashboard.html`.

```bash
# تشغيل الداشبورد فقط
npm run dashboard

# تشغيل البوت والداشبورد معاً
npm run start:all
```

بعد التشغيل افتح المتصفح على:
- **محلي:** `http://localhost:3000`
- **دومين:** `http://dashboard.mysite.com` (حسب DASHBOARD_HOST)

### إعداد الهوست/الدومين من الداشبورد

1. افتح الداشبورد في المتصفح
2. اضغط على **🌐 الهوست / الدومين** في القائمة الجانبية
3. أدخل عنوان الهوست أو الدومين والمنفذ
4. انسخ القيم وضعها في ملف `.env`
5. أعد تشغيل السيرفر

---

## 🗄️ قاعدة البيانات (MongoDB)

جميع البيانات تُخزَّن في MongoDB بالكامل — لا يوجد أي استخدام لـ `quick.db` أو SQLite.

| النموذج | الوصف |
|---------|-------|
| `Guild` | إعدادات السيرفر (حماية، ترحيب، تذاكر، ليفل...) |
| `Member` | بيانات الأعضاء (XP، تحذيرات، عملات، مستوى) |
| `Ticket` | بيانات التذاكر (مفتوح، مغلق، رسائل) |
| `ShopProduct` | منتجات المتجر (رتب، كودات، رقمي) |

---

## 📋 إعداد البوت في السيرفر

بعد تشغيل البوت، استخدم الأوامر التالية:

```
/setup logs    channel:#void-logs       → تفعيل سجل الإدارة
/setup welcome channel:#welcome         → تفعيل الترحيب
/setup levels  enabled:true             → تفعيل الليفل
/ticket setup  category:... support:... → إعداد التذاكر
/ticket panel                           → إنشاء بانيل التذاكر
/security status                        → عرض حالة الحماية
```

---

## 📁 هيكل المشروع

```
void-bot/
├── index.js                  ← الملف الرئيسي (البوت)
├── dashboard.js              ← سيرفر الداشبورد (Express)
├── void-dashboard.html       ← واجهة الداشبورد
├── config.js                 ← الإعدادات المركزية
├── .env                      ← متغيرات البيئة
│
├── commands/
│   ├── moderation/           ← ban, kick, mute, warn, clear, lock...
│   ├── tickets/              ← نظام التذاكر
│   ├── levels/               ← rank, leaderboard, setlevel
│   ├── suggestions/          ← suggest
│   ├── security/             ← security
│   ├── ai/                   ← ai
│   ├── store/                ← shop (MongoDB)
│   └── utility/              ← help, setup, ping, userinfo, serverinfo, stats
│
├── events/
│   ├── ready.js              ← يقرأ DASHBOARD_HOST من .env
│   ├── interactionCreate.js
│   ├── messageCreate.js
│   ├── guildMemberAdd.js
│   ├── guildMemberRemove.js
│   ├── messageDelete.js
│   └── messageUpdate.js
│
├── systems/
│   ├── leveling.js
│   ├── protection.js
│   ├── tickets.js
│   ├── modlog.js
│   ├── automod.js
│   ├── welcome.js
│   └── scheduler.js
│
├── models/                   ← نماذج MongoDB
│   ├── Guild.js
│   ├── Member.js
│   ├── Ticket.js
│   └── ShopProduct.js        ← جديد: منتجات المتجر
│
├── handlers/
│   ├── commandHandler.js
│   └── eventHandler.js
│
└── utils/
    ├── embed.js
    ├── permissions.js
    └── logger.js
```

---

## 🎯 قائمة الأوامر

### 🛡️ الإدارة
| الأمر | الوصف |
|-------|-------|
| `/ban` | حظر عضو |
| `/unban` | رفع الحظر |
| `/kick` | طرد عضو |
| `/mute` | كتم مؤقت |
| `/unmute` | رفع الكتم |
| `/warn` | تحذير عضو |
| `/warnings` | عرض/حذف التحذيرات |
| `/clear` | حذف رسائل |
| `/lock` | قفل روم أو السيرفر |
| `/slowmode` | تفعيل السلو مود |

### 🔒 الحماية
| الأمر | الوصف |
|-------|-------|
| `/security status` | حالة جميع الأنظمة |
| `/security antispam` | تشغيل/إيقاف |
| `/security antilinks` | تشغيل/إيقاف |
| `/security antiraid` | تشغيل/إيقاف |
| `/security antimention` | تشغيل/إيقاف |
| `/security antinewaccount` | تشغيل/إيقاف |

### 🎫 التذاكر
| الأمر | الوصف |
|-------|-------|
| `/ticket setup` | إعداد النظام |
| `/ticket panel` | إنشاء البانيل |
| `/ticket list` | التذاكر المفتوحة |
| `/ticket add` | إضافة عضو |
| `/ticket remove` | إزالة عضو |

### ⭐ الليفل
| الأمر | الوصف |
|-------|-------|
| `/rank` | عرض مستواك |
| `/leaderboard` | لوحة المتصدرين |
| `/setlevel set` | تحديد مستوى |
| `/setlevel addxp` | إضافة XP |
| `/setlevel reset` | إعادة تصفير |

### 🛒 المتجر (MongoDB)
| الأمر | الوصف |
|-------|-------|
| `/shop view` | عرض المنتجات |
| `/shop buy <id>` | شراء منتج |
| `/shop add` | إضافة منتج (إداري) |
| `/shop remove <id>` | حذف منتج (إداري) |
| `/shop balance` | عرض رصيد العملات |

### 🤖 الذكاء الاصطناعي (Premium)
| الأمر | الوصف |
|-------|-------|
| `/ai announce` | كتابة إعلان |
| `/ai rules` | كتابة قوانين |
| `/ai summary` | تلخيص نص |
| `/ai translate` | ترجمة |
| `/ai ideas` | اقتراح أفكار |
| `/ai names` | اقتراح أسماء |

### 🔧 الأدوات
| الأمر | الوصف |
|-------|-------|
| `/help` | قائمة الأوامر |
| `/setup` | إعداد البوت |
| `/ping` | حالة البوت |
| `/userinfo` | معلومات عضو |
| `/serverinfo` | معلومات السيرفر |
| `/stats` | إحصائيات السيرفر |

---

## 💎 خطط الاشتراك

| الميزة | مجاني | Premium | Ultimate |
|--------|-------|---------|----------|
| أوامر أساسية | ✅ | ✅ | ✅ |
| حماية محدودة | ✅ | ✅ | ✅ |
| تذاكر (3 مفتوحة) | ✅ | ✅ | ✅ |
| حماية متقدمة | ❌ | ✅ | ✅ |
| تذاكر غير محدودة | ❌ | ✅ | ✅ |
| ترحيب بالصور | ❌ | ✅ | ✅ |
| AI (OpenAI) | ❌ | ✅ | ✅ |
| تخصيص كامل | ❌ | ❌ | ✅ |
| دعم أولوية | ❌ | ❌ | ✅ |

---

## 📞 الدعم

- **Discord:** discord.gg/void
- **المطور:** @void_dev

---

*Void Bot v1.0.0 — صُنع بـ ❤️ للمجتمع العربي*
